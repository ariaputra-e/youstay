<?php
	include "php/connection.php";
	session_start();

	if (!isset($_SESSION['kode'])){
		die ("<script type='text/javascript'>alert ('Anda harus Log-in Terlebih Dahulu!'); window.location.href = 'profile.php'; </script>");
	}
	$kdHotel = $_GET['id'];

	$query = $connection->prepare("
		select hotel.kdHotel, hotel.kdRegion, hotel.nama_hotel, hotel.deskripsi, region.nama_region, region.direktori_foto, region.deskripsi_region, gallery.direktori
			from region 
			inner join hotel on region.kdRegion = hotel.kdRegion
			inner join gallery on hotel.kdHotel = gallery.kdHotel
			where right(direktori, 3) = '(1)' and hotel.kdHotel= :kdHotel; 
		");
	$query->bindParam(":kdHotel", $_GET['id']);
	$query->execute();
	$data1 = $query->fetch();

	$sKode = $_SESSION['kode'];

	$query = "select * from users where kode = ('$sKode')";

	$statement = $connection->prepare($query);
	$statement->execute();

	$data2 = $statement->fetch();
?>

<!DOCTYPE html>
<html>
<head>
	<link href='https://fonts.googleapis.com/css?family=Fahkwang' rel='stylesheet'>
	<link href='https://fonts.googleapis.com/css?family=Coda Caption:800' rel='stylesheet'>
	<title><?php echo $data1['nama_hotel']; ?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="bs/bootstrap.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.js"></script>
  <script src="bs/bootstrap.js"></script>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<button onclick="topFunction()" id="myBtn" title="Go to top">Top</button> 
<div class ="container">
	<div class="header">
		<div class="logo"> 
			<img src="assets/image/logo.png" width="400em">
		</div>
		<div class="navbar">
			<ul>
			  <li><a class="active" href="index.php">Home</a></li>
			  <li><a href="browse_hotels.php">Hotels</a></li>
			  <li><a href="contact.php">About Us</a></li>
			   <li><a href="
			  	<?php 
			  		if(isset($_SESSION['kode'])){
			  			echo "user_page.php";
			  		} else {
			  			echo "profile.php";
			  		} 
			  	?>">YOU <img src="assets/image/user.png" width="20px"></a></li>
			  <?php
			  if(isset($_SESSION['kode'])){
			  		echo "<li><a href='log-out.php'>Logout</a></li>";
				}
			  ?>
			</ul>
		</div>
	</div>
	<div class="body htl">
			<div class="container">
				<div class="row">
					<div class="col-md-8 content-htl" style="padding: 10px; margin-top: 3em;">
						<div class="row" style="position: relative; left: 2em;">
							<div class="col-md" style="padding-left: .5em; padding-top: 1em; white-space: nowrap;">
								<h1 style="font-weight: 800;"><?php echo $data1['nama_hotel']; ?></h1>
							</div>
							<div class="col-md" style="font-size: .9vw; text-align: right; padding-top: 1.5em; padding-left: 5em; position: relative; right: 4em; top: 1em;">
									<?php echo $data1['nama_region']; ?> | 0 Reviews
							</div>
						</div>
						<div class="row" style="width: 100%;">
							<div class="col-md" style="width: 100%; margin-top: 1em; margin-left: 2em; background-size: cover;height: 350px; background-image: url('assets/image/hotels/<?php echo $data1['kdHotel']."/".$data1['direktori']; ?>.jpg');">
							</div>
						</div>
						<div class="row" style="margin-top: 1em; padding: 30px;">
							<div class="col-md">
								<p>
									<?php echo $data1['deskripsi']; ?> 
								</p>

								<blockquote class="blockquote text-center">
									<p class="mb-0">This Hotel is Fabulous!!!</p>
									<footer class="blockquote-footer">
										Aria Eka <cite title="Source Title">Jakarta Traveler</cite></footer>
								</blockquote>
							</div>
						</div>
						<div class="row" style="margin-top: 1em; padding: 30px;">
							<table style="border-collapse: collapse; border-spacing: 100px; width: 100%;">
								<tr>
									<td colspan="4">Facilities :</td>
								</tr>
								<?php 
								$query = $connection->prepare("select ft_facilities.kdFT, ft_facilities.kdFacilities, facilities.nama_facilities, hotel.nama_hotel
									from ft_facilities
									inner join facilities on ft_facilities.kdFacilities = facilities.kdFacilities
									inner join hotel on ft_facilities.kdHotel = hotel.kdHotel
									where hotel.kdHotel = :kdHotel;");
								$query->bindParam(":kdHotel", $_GET['id']);
								$query->execute();
								?>
								<tr class="facilities">
									<?php 
										while ($fac = $query->fetch()) {
									?> 
									<td style="border: 1px solid grey; text-align: center;"><?php 
									echo  $fac['nama_facilities'];
									?></td>
									<?php } ?>
								</tr>
							</table>
						</div>
						<div class="row" style="margin-top: 1em; position: relative; left: 1em; width: 100%; border-top: 7px solid grey;">
							<div class="col-md-2" style="height: 150px; width:200px; background-size: cover; background-image: url('assets/upload/<?php echo $data2['foto']; ?>.jpg'); margin-top: 1em;">
							</div>
							<div class="col-md-10" style="height: 150px; width:200px; margin-top: 2em; padding-left: 1em;">
								<h2><b>Booking as <?php echo $_SESSION['nama_pertama']." ".$_SESSION['nama_belakang']; ?></b></h2>
								<p>You can order for yourself or make an order for others! <br /><a href="profile.php">Click here to edit your profile info!</a></p>
							</div>
						</div>
						<div class="row" style="margin-top: 1em; position: relative; left: 1em; width: 100%; border-top: 1px solid grey;">
							<div class="col-md" style="margin-top: 1em; text-align: center;">
								<div class="row">
									<div class="col-md">
										<h2><b><u>Leave a Review</u></b></h2>
									</div>
								</div>
								<div class="row">
									<div class="col-md">
										<span class="row">Your Rating</span>
										<span class="row" style="margin-bottom: 2em;">
											<img src="assets/image/h_empty.png">
											<img src="assets/image/h_empty.png">
											<img src="assets/image/h_empty.png">
											<img src="assets/image/h_empty.png">
											<img src="assets/image/h_empty.png">
										</span>
										<span class="row">Your Comment (Optional)</span>
										<span class="row" style="width: 100%;">
											<textarea name="comment" style="width: 100%; border: none; padding: 10px;height: 15em; background-color: rgba(0, 0, 0, .3);" placeholder="Enter your comment..."></textarea>
										</span>
										<span class="row" style="margin-top: 2em;">
											<input type="submit" value="Submit Review" class="btnReview">
										</span>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4" style="padding: 10px; position: relative; left: 1em;">
						<div class="content-htl" style="padding: 10px; margin: -.6em 0em 1em 0em;">
							<span class="row">
								<h1 style="margin: .2em 0em 0em 1em;">About Region</h1>
							</span>
							<span class="row square" style="margin: 1em 0em 1em .7em; background-image: url('assets/image/<?php echo $data1['direktori_foto']; ?>.jpg');">
								
							</span>
							<span class="row desc">
								<p>
									<?php  
										echo $data1['deskripsi_region'];
									?>
								</p>
							</span>
						</div>
						<div class="content-htl" style="padding: 10px; margin: .6em 0em 1em 0em;">
							<span class="row">
								<h1 style="margin: .2em 0em 0em 1em;">Room Available</h1>
							</span>
							<span class="row desc">
								<table width="100%">
									<tr>
										<?php
											$query = $connection->prepare("select hotel.kdHotel, room.nm_kamar, room.kd_kamar, room.hargaPerNight, room.kd_kamar, gallery_room.directory
											    from hotel
												inner join room on hotel.kdHotel = room.kdHotel
												inner join gallery_room on room.kd_kamar = gallery_room.kd_kamar
												where hotel.kdHotel = :kdHotel order by room.hargaPerNight asc;");
												$query->bindParam(":kdHotel", $_GET['id']);
												$query->execute();

												while ($data2 = $query->fetch()){
													 ?>
										<td height="100px" style=" max-height: 100px; padding-bottom: 0; position: relative; bottom: 1em;"><?php 
											echo "<img style='object-fit: contain; max-width:100%; max-height:100px;' src='assets/image/hotels/".$data2['kdHotel']."/".$data2['directory'].".jpg'>";?></td>
											<td style="margin-left: 1em;font-size: .8vw; position: relative; bottom: 1em;">
											<b><?php echo $data2['nm_kamar']; ?> <br /></b>
											
											<?php echo "Rp. ".number_format($data2['hargaPerNight']).",-";?> <br />
											<button type="submit" data-id="<?php echo $data2['kd_kamar']; ?>" class="btn btn-default addRoom" data-toggle="modal" data-target="#form">Book</button>
										</td>
									</tr>
									<?php } ?>
								</table>
							</span>
						</div>
<!-- Untuk Form Popup -->
<div class="modal fade" id="form" tabindex="-1" role="dialog" aria-labelledby="form" aria-hidden="true" style="margin-top: 2em;">
     <div class="modal-dialog">
     	<div class="modal-content" style="margin-top: 10em; vertical-align: middle;">
     		<!-- Modal Header -->
     		<div class="modal-header" style="margin-right: 9em; margin-top: 4px; border: none;">
                <button type="button" class="close" data-dismiss="modal">
                       <span aria-hidden="true">&times;</span>
                       <span class="sr-only">Close</span>
                </button>
                <h2 class="modal-title bold" style="text-align: center;" id="form">
                    &nbsp; Please Confirm Below
                </h2>
            </div>
            <!-- Modal Body -->
            <div class="modal-body" style="padding: 1em;">
            	<?php 
            		$idBook = uniqid('BK');
            	?>
            	<form role="form" method="post" action="php/confirmation-process.php">
            		<input type="hidden" name="kdBooking" value="<?php echo $idBook; ?>">
            		<input type="hidden" name="hotel" value="<?php echo $_GET['id']; ?>">
            		<input type="hidden" name="room" id="roomID" value="">
            		<div class="form-group">
            			<table style="width: 100%;">
            				<tr>
            					<td>	
            						<label>Check In</label>
            						<input name="inputDateIn" style="width: 50%;" type="date" class="form-control" placeholder="hh/bt"/>
            					</td>
            					<td style="position: relative; bottom: .5em; right: 6em;">	
            						 <label style="margin-top: 1em;">Check Out</label>
            						 <input name="inputDateOut" style="width: 50%;" type="date" class="form-control" placeholder="hh/bt"/>
            					</td>
            				</tr>
            			</table>
            		</div>
            		<div class="form-group">
            			<label>Room</label>
            			<input name="qty" style="width: 80%;" type="text" class="form-control" placeholder="Number of rooms (e.g. 2)"/>
            		</div>
            		<div class="form-group">
            			<label>Children</label>
            			<input name="qtyChild" style="width: 80%;" type="text" class="form-control" placeholder="Number of Children (e.g. 2)"/>
            		</div>
            		<div class="form-group">
            			<label>Adult</label>
            			<input name="qtyAdult" style="width: 80%;" type="text" class="form-control" placeholder="Number of Adult (e.g. 2)"/>
            		</div>
            		<div class="form-group">
            			<label>Promotional Code</label>
            			<input style="background-color: rgba(0,0,0,.2);" type="text" class="form-control promo" name="promo" placeholder="Enter a Promotional Code..."/>
            		</div>
            		<div class="radio">
            			<label>
            				<input type="radio" value="Yes" name="smoke"> Smoke Room
            			</label>
            		</div>
            		<button style="margin-left: 13em;" type="submit" class="confirm" onclick="getDefault();">
            			Book
            		</button>
                </form>  
            </div>
            <!-- Modal Footer -->
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">
                    Close
                </button>
            </div>
        </div>
    </div>
</div>
<!-- End of Form Modal -->
						<div class="content-htl" style="padding: 10px; margin: -.6em 0em 1em 0em;">
							<span class="row">
								<h1 style="margin: .2em 0em 0em 1em;">Gallery</h1>
							</span>
							<?php
								$query = $connection->prepare("
									select hotel.kdHotel, gallery.direktori
									from hotel
									inner join gallery on hotel.kdHotel = gallery.kdHotel
									where hotel.kdHotel = :kdHotel");
								$query->bindParam(":kdHotel", $_GET['id']);
								$query->execute();
?>

							<span class="row gallery" style="margin-top: 1em;">
							<?php while($gallery = $query->fetch()){
							?>
								<span class="col-md-6" style="margin-bottom: 1em;">	
								<?php 
									echo "<a href='assets/image/hotels/".$_GET['id']."/".$gallery['direktori'].".jpg' data-toggle='lightbox' data-gallery='hotel-gallery'>"."<img class='img-fluid' style='object-fit: contain; max-width:100%; max-height:100px;' src='assets/image/hotels/".$_GET['id']."/".$gallery['direktori'].".jpg'>";?></a>
								</span>
									  <?php } ?>
							</span>
						</div>
					</div>
				</div>
			</div>
	</div>
</div>
<div class="footer">
	<div class="ft-item">
		<img src="assets/image/logo.png" width="50%">
		<span><p>For more further information <br />please contact us.</p></span>
	</div>
	<div class="ft-item">
		<span class="title"><p>QUICK LINKS</p></span>
		<span class="links">
			<p>About Us</p>
			<p>Our Hotels</p>
			<p>Your Profile</p>
			<p>Admin Page</p>
		</span>
	</div>
	<div class="ft-item" style=" position: relative; top: 4em; left: 6em;">
		<img src="assets/image/fb.png" style="width: 10%;"> 
		<img src="assets/image/ig.png" style="width: 10%;">
	</div>
	<div class="ft-item">
		<div class="title-ig">INSTAGRAM</div>
		<div class="ig">
			<div class="ig-item">
				<img src="assets/image/37.jpg">
			</div>
			<div class="ig-item">
				<img src="assets/image/38.jpg">
			</div>
			<div class="ig-item">
				<img src="assets/image/33.jpg">
			</div>
			<div class="ig-item">
				<img src="assets/image/34.jpg">
			</div>
			<div class="ig-item">
				<img src="assets/image/35.jpg">
			</div>
			<div class="ig-item">
				<img src="assets/image/36.jpg">
			</div>
		</div>
	</div>
	<div class="copyright">
		&copy; Aria Eka Putra. 2019.
	</div>
</div>
<script type="text/javascript">
		$(document).on('click', '[data-toggle="lightbox"]', function(event) {
                event.preventDefault();
                $(this).ekkoLightbox();
            });
</script>
<script type="text/javascript" src="script.js"></script>
</body>
</html>