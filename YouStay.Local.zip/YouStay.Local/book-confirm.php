<?php
	include "php/connection.php";
	session_start();

	if(!isset($_SESSION['kode'])){
		echo "<script type='text/javascript'> alert('You need to log-in before proceed!');";
		echo "window.location.href = 'profile.php'; </script>";
	}

	$query = $connection->prepare("select users.nama_pertama, users.nama_belakang, users.email, users.telepon, users.since, 
		booking.checkin, booking.checkout, booking.kdBooking
		from users
		inner join booking on users.kode = booking.kode
		where booking.kdBooking = :kdBooking");
	$query->bindParam(":kdBooking", $_SESSION['kdBooking']);
	$query->execute();
	$row = $query->fetch();
?>

<!DOCTYPE html>
<html>
<head>
	<link href='https://fonts.googleapis.com/css?family=Fahkwang' rel='stylesheet'>
	<link href='https://fonts.googleapis.com/css?family=Coda Caption:800' rel='stylesheet'>
	<title>Booking Confirmation</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="bs/bootstrap.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="bs/bootstrap.js"></script>
	<link rel="stylesheet" href="style.css">
</head>
<body>
<button onclick="topFunction()" id="myBtn" title="Go to top">Top</button> 
<div class ="container">
	<div class="header">
		<div class="logo"> 
			<img src="assets/image/logo.png" width="400em">
		</div>
		<div class="navbar">
			<ul>
			  <li><a class="active" href="index.php">Home</a></li>
			  <li><a href="browse_hotels.php">Hotels</a></li>
			  <li><a href="contact.php">About Us</a></li>
			<li><a href="
			  	<?php 
			  		if(isset($_SESSION['kode'])){
			  			echo "user_page.php";
			  		} else {
			  			echo "profile.php";
			  		} 
			  	?>">YOU <img src="assets/image/user.png" width="20px"></a></li>
			  	<?php
			  if(isset($_SESSION['kode'])){
			  		echo "<li><a href='log-out.php'>Logout</a></li>";
				}
			  ?>
			</ul>
		</div>
	</div>
	<div class="body" style="margin-top: 5em;">
		<div class="row" style="width: 100%; padding: 10px;">	<h2 style="color: grey; font-family: Century Gothic, CenturyGothic, AppleGothic, sans-serif; font-size: 29pt; font-weight: 800;">Confirm Booking</h2>
			<div class="col-md" style=" margin: 0, auto; text-align: center;">
				<img src="assets/image/prog_1.jpg" />
			</div>
		</div>
		<div class="container" style="width: 100%;">
			<div class="rw">
				<div class="conf">
					<table border="0" width="100%">
						<tr>
							<td class="bold">Full Name</td>
							<td><?php echo $row['nama_pertama']." ".$row['nama_belakang']; ?></td>
						</tr>
						<tr>
							<td class="bold">Email</td>
							<td><?php echo $row['email']; ?></td>
						</tr>
						<tr>
							<td class="bold">Mobile Number</td>
							<td><?php echo $row['telepon']; ?></td>
						</tr>
						<tr>
							<td class="bold">Member Since</td>
							<td><?php echo $row['since']; ?></td>
						</tr>
						<tr>
							<td colspan="2"><a href="profile.php">Edit Profile Info</a></td>
						</tr>
					</table>
				</div>
				<div class="conf">
					<table border="0" width="100%">
						<tr>
							<td class="bold">Check-in</td>
							<td><?php echo $row['checkin']; ?></td>
						</tr>
						<tr>
							<td class="bold">Check-out</td>
							<td><?php echo $row['checkout']; ?></td>
						</tr>
					</table>
					<span class="row" style="position: relative; left: 25em;"><?php $link = "payment-confirm.php?bookNo=".$_SESSION['kdBooking']; ?>
						<a href="<?php echo $link; ?>"><button type="submit" class="confirm">Continue</button></a>
					</span>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="footer">
	<div class="ft-item">
		<img src="assets/image/logo.png" width="50%">
		<span><p>For more further information <br />please contact us.</p></span>
	</div>
	<div class="ft-item">
		<span class="title"><p>QUICK LINKS</p></span>
		<span class="links">
			<p>About Us</p>
			<p>Our Hotels</p>
			<p>Your Profile</p>
			<p>Admin Page</p>
		</span>
	</div>
	<div class="ft-item" style=" position: relative; top: 4em; left: 6em;">
		<img src="assets/image/fb.png" style="width: 10%;"> 
		<img src="assets/image/ig.png" style="width: 10%;">
	</div>
	<div class="ft-item">
		<div class="title-ig">INSTAGRAM</div>
		<div class="ig">
			<div class="ig-item">
				<img src="assets/image/37.jpg">
			</div>
			<div class="ig-item">
				<img src="assets/image/38.jpg">
			</div>
			<div class="ig-item">
				<img src="assets/image/33.jpg">
			</div>
			<div class="ig-item">
				<img src="assets/image/34.jpg">
			</div>
			<div class="ig-item">
				<img src="assets/image/35.jpg">
			</div>
			<div class="ig-item">
				<img src="assets/image/36.jpg">
			</div>
		</div>
	</div>
	<div class="copyright">
		&copy; Aria Eka Putra. 2019.
	</div>
</div>
<script type="text/javascript" src="script.js"></script>
</body>
</html>