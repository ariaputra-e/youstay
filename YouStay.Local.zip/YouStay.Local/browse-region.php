<?php
	include "php/connection.php";

	session_start();

	$region = $_GET['reg'];

	$query = $connection->prepare("select region.kdRegion, region.nama_region, hotel.nama_hotel, hotel.kdHotel from hotel inner join region on hotel.kdRegion = region.kdRegion where kdRegion = :kdRegion;");
	$query->bindParam(":kdRegion", $region);
	//$gallery = "select * from gallery where kdHotel = ?";
	//$price = "select * from room where kdHotel = ? order by hargaPerNight asc limit 1";

	try{
		$query->execute();
	} 
	catch (PDOException $e) {
        echo "Error : " . $e->getMessage();
    }
?>

<!DOCTYPE html>
<html>
<head>
	 <meta charset="UTF-8">
	<link href='https://fonts.googleapis.com/css?family=Fahkwang' rel='stylesheet'>
	<link href='https://fonts.googleapis.com/css?family=Coda Caption:800' rel='stylesheet'>
	<title>Available Hotels in <?php echo $reg['nama_region']; ?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="bs/bootstrap.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="bs/bootstrap.js"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.9/dist/css/bootstrap-select.min.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.9/dist/js/bootstrap-select.min.js"></script>
	<link rel="stylesheet" href="style.css">
</head>
<body>
<button onclick="topFunction()" id="myBtn" title="Go to top">Top</button> 
<div class ="container">
	<div class="header">
		<div class="logo"> 
			<img src="assets/image/logo.png" width="400em">
		</div>
		<div class="navbar">
			<ul>
			 <li><a class="active" href="index.php">Home</a></li>
			  <li><a href="browse_hotels.php">Hotels</a></li>
			  <li><a href="contact.php">About Us</a></li>
			  <li><a href="
			  	<?php 
			  		if(isset($_SESSION['kode'])){
			  			echo "user_page.php";
			  		} else {
			  			echo "profile.php";
			  		} 
			  	?>">YOU <img src="assets/image/user.png" width="20px"></a></li>
			  <?php
			  if(isset($_SESSION['kode'])){
			  		echo "<li><a href='log-out.php'>Logout</a></li>";
				}
			  ?>
			</ul>
		</div>
	</div>
	<div class="body">
		<div class="container">
			<div class="row bHotel" style="border-bottom: 1px solid grey; position: relative; top: 1em;">
				<div class="col-md-4" style="margin-right: 5em;">
					<h2>Available Hotels</h2>
				</div>
				<div class="col-md-4 select" style="position: relative; top: 2em; left: 27em;">
					<select name="sort" class="selectpicker" multiple title="Sort by...">
					 	<option>Region</option>
					 	<option>Price Low to High</option>
					 	<option>Price High to Low</option>
					</select>
				</div>
			</div>
			<div class="row centeredItems">
			<?php 
				while ($reg = $query->fetch()){
			?>
				<div class="col-md-4">
					<?php
						$kdHotel = $reg['kdHotel'];

						/** $query2 = "select hotel.kdHotel, gallery.direktori, room.hargaPerNight
						from ((hotel 
						inner join gallery on hotel.kdHotel = gallery.kdHotel)
						inner join room on hotel.kdHotel = room.kdHotel);"; **/

						$query2 = "select hotel.kdHotel, avg(room.hargaPerNight),
						from hotel inner join room on hotel.kdHotel = room.kdHotel 
						where hotel.kdHotel = '$kode'' group by kdHotel;";

						try{
							$statement2 = $connection->prepare($query2);
							$statement2->execute();
							$data2 = $statement2->fetch();	
						} 
						catch (PDOException $e) {
						    echo "Error : " . $e->getMessage();
						}	

						$query3 = "select hotel.kdHotel, nama_hotel, hotel.deskripsi, gallery.direktori, region.nama_region
							from hotel
							inner join region on hotel.kdRegion = region.kdRegion
							inner join gallery on gallery.kdHotel = hotel.kdHotel
							where right(direktori, 3) = '(1)' and region.kdRegion = :kdRegion;";
						try{
							$statement3 = $connection->prepare($query3);
							$statement3->execute();
							$foto = $statement3->fetch();	
						} 
						catch (PDOException $e) {
						    echo "Error : " . $e->getMessage();
						}
						$link = "hotels.php?id=".$data['kdHotel'];
						$kode = $data['kdHotel'];
					?><form action="">
					<?php echo "<a href='$link'>"; ?> <div class="img__wrap">
						<img class="img__img img-responsive" src="assets/image/hotels/<?php echo $data['kdHotel']."/".$foto['direktori']; ?>.jpg" style="width: 100%; height: 200px;" />
						<p class="img__description"><?php echo $data['nama_hotel'];  ?></p>
					</div><?php echo "</a>"; ?></form>
					<div class="row details">
						<div class="col-md-12">
							<?php echo substr($data['deskripsi'], 0, 90). "..."; ?>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6" style="text-align: left;">
							<h6>Price per Night: <br />
							<?php echo "Rp. ".number_format($data2['avg(room.hargaPerNight)'])."++"; ?></h6>
						</div>
						<div class="col-md-6" style="text-align: right; position: relative; top: 9px;">
							<?php echo "<a href='$link'>"; ?><button type="button" class="btn btn-dark">Check</button><?php echo "</a>"; ?>
						</div>
					</div>
				</div>
			<?php } ?>
			<a href="#"><div class="row">
				<div class="col-md-12 see-more">
					See more hotels..
				</div>
			</div>
		</a>
		</div>
	</div>
</div>
<div class="footer">
	<div class="ft-item">
		<img src="assets/image/logo.png" width="50%">
		<span><p>For more further information <br />please contact us.</p></span>
	</div>
	<div class="ft-item">
		<span class="title"><p>QUICK LINKS</p></span>
		<span class="links">
			<p>About Us</p>
			<p>Our Hotels</p>
			<p>Your Profile</p>
			<p>Admin Page</p>
		</span>
	</div>
	<div class="ft-item" style=" position: relative; top: 4em; left: 6em;">
		<img src="assets/image/fb.png" style="width: 10%;"> 
		<img src="assets/image/ig.png" style="width: 10%;">
	</div>
	<div class="ft-item">
		<div class="title-ig">INSTAGRAM</div>
		<div class="ig">
			<div class="ig-item">
				<img src="assets/image/37.jpg">
			</div>
			<div class="ig-item">
				<img src="assets/image/38.jpg">
			</div>
			<div class="ig-item">
				<img src="assets/image/33.jpg">
			</div>
			<div class="ig-item">
				<img src="assets/image/34.jpg">
			</div>
			<div class="ig-item">
				<img src="assets/image/35.jpg">
			</div>
			<div class="ig-item">
				<img src="assets/image/36.jpg">
			</div>
		</div>
	</div>
	<div class="copyright">
		&copy; Aria Eka Putra. 2019.
	</div>
</div>
<script type="text/javascript" src="script.js"></script>
</body>
</html>