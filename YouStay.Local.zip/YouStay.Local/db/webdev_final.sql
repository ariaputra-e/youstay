-- --------------------------------------------------------
-- Host:                         localhost
-- Server version:               5.7.19 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for webdev
CREATE DATABASE IF NOT EXISTS `webdev` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `webdev`;

-- Dumping structure for table webdev.booking
CREATE TABLE IF NOT EXISTS `booking` (
  `kdBooking` varchar(30) NOT NULL,
  `checkin` date DEFAULT NULL,
  `checkout` date DEFAULT NULL,
  `qtyRoom` int(11) DEFAULT NULL,
  `qtyChild` int(11) DEFAULT NULL,
  `qtyAdult` int(11) DEFAULT NULL,
  `kdPromosi` varchar(50) NOT NULL DEFAULT '0',
  `smoke` char(3) DEFAULT NULL,
  `kode` int(11) DEFAULT NULL,
  `kdHotel` varchar(50) DEFAULT NULL,
  `kd_kamar` int(11) DEFAULT NULL,
  `status` varchar(50) DEFAULT 'Waiting for Payment',
  `created` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kdBooking`),
  UNIQUE KEY `kdBooking` (`kdBooking`),
  KEY `FK_booking_hotel` (`kdHotel`),
  KEY `FK_booking_room` (`kd_kamar`),
  KEY `FK_booking_users` (`kode`),
  CONSTRAINT `FK_booking_hotel` FOREIGN KEY (`kdHotel`) REFERENCES `hotel` (`kdHotel`),
  CONSTRAINT `FK_booking_room` FOREIGN KEY (`kd_kamar`) REFERENCES `room` (`kd_kamar`),
  CONSTRAINT `FK_booking_users` FOREIGN KEY (`kode`) REFERENCES `users` (`kode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table webdev.booking: ~7 rows (approximately)
/*!40000 ALTER TABLE `booking` DISABLE KEYS */;
INSERT INTO `booking` (`kdBooking`, `checkin`, `checkout`, `qtyRoom`, `qtyChild`, `qtyAdult`, `kdPromosi`, `smoke`, `kode`, `kdHotel`, `kd_kamar`, `status`, `created`) VALUES
	('BK5cd90dcb3578b', '2019-06-28', '2019-06-02', 1, 0, 1, 'sdsad', 'Yes', 11, 'JK000003', 5, 'Waiting for Payment', '2019-05-13 13:25:45'),
	('BK5cd91444e37fd', '2019-05-15', '2019-05-31', 1, 0, 1, '0', 'No', 11, 'BD000003', 10, 'Paid', '2019-05-13 13:53:17'),
	('BK5cd9161034b86', '1970-01-01', '2019-05-15', 1, 0, 1, '0', 'No', 13, 'BD000003', 10, 'Waiting for Payment', '2019-05-13 14:00:44'),
	('BK5cd91621ab7e3', '2019-05-22', '2019-05-23', 1, 0, 1, '0', 'No', 13, 'BD000003', 10, 'Waiting for Payment', '2019-05-13 14:01:08'),
	('BK5cd9163c3a327', '2019-05-20', '2019-05-22', 1, 0, 1, '0', 'No', 13, 'BD000003', 10, 'Waiting for Payment', '2019-05-13 14:01:44'),
	('BK5cd9165d183fe', '2019-06-20', '2019-06-22', 1, 0, 1, '0', 'No', 13, 'BD000003', 10, 'Waiting for Payment', '2019-05-13 14:02:05'),
	('BK5cd91db3af180', '2019-05-15', '2019-05-17', 1, 0, 1, '0', 'No', 14, 'BD000003', 10, 'Cancelled', '2019-05-13 14:36:10'),
	('BK5cd91f971a680', '2019-05-14', '2019-05-17', 1, 0, 1, '0', 'No', 14, 'BD000002', 7, 'Waiting for Payment', '2019-05-13 14:41:31');
/*!40000 ALTER TABLE `booking` ENABLE KEYS */;

-- Dumping structure for table webdev.facilities
CREATE TABLE IF NOT EXISTS `facilities` (
  `kdFacilities` char(3) NOT NULL,
  `nama_facilities` varchar(255) DEFAULT NULL,
  `direktori_ikon` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`kdFacilities`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table webdev.facilities: ~10 rows (approximately)
/*!40000 ALTER TABLE `facilities` DISABLE KEYS */;
INSERT INTO `facilities` (`kdFacilities`, `nama_facilities`, `direktori_ikon`) VALUES
	('F01', 'WiFi', NULL),
	('F02', 'Kolam Renang', NULL),
	('F03', 'Parkir', NULL),
	('F04', 'Restoran', NULL),
	('F05', 'Resepsionis 24 Jam', NULL),
	('F06', 'Lift', NULL),
	('F07', 'Akses Kursi Roda', NULL),
	('F08', 'Pusat Kebugaran', NULL),
	('F09', 'Fasilitas Rapat', NULL),
	('F10', 'Antar Jemput Bandara', NULL);
/*!40000 ALTER TABLE `facilities` ENABLE KEYS */;

-- Dumping structure for table webdev.ft_facilities
CREATE TABLE IF NOT EXISTS `ft_facilities` (
  `kdFT` int(11) NOT NULL AUTO_INCREMENT,
  `kdHotel` varchar(8) NOT NULL DEFAULT '0',
  `kdFacilities` char(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`kdFT`),
  KEY `FK_ft_facilities_hotel` (`kdHotel`),
  KEY `FK_ft_facilities_facilities` (`kdFacilities`),
  CONSTRAINT `FK_ft_facilities_facilities` FOREIGN KEY (`kdFacilities`) REFERENCES `facilities` (`kdFacilities`),
  CONSTRAINT `FK_ft_facilities_hotel` FOREIGN KEY (`kdHotel`) REFERENCES `hotel` (`kdHotel`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;

-- Dumping data for table webdev.ft_facilities: ~39 rows (approximately)
/*!40000 ALTER TABLE `ft_facilities` DISABLE KEYS */;
INSERT INTO `ft_facilities` (`kdFT`, `kdHotel`, `kdFacilities`) VALUES
	(1, 'BD000001', 'F05'),
	(2, 'BD000001', 'F06'),
	(3, 'BD000001', 'F01'),
	(4, 'BD000001', 'F04'),
	(5, 'JK000003', 'F06'),
	(6, 'JK000003', 'F01'),
	(8, 'JK000003', 'F02'),
	(10, 'JK000003', 'F05'),
	(11, 'BD000002', 'F06'),
	(12, 'BD000002', 'F02'),
	(13, 'BD000002', 'F03'),
	(15, 'BD000002', 'F05'),
	(17, 'BD000003', 'F05'),
	(18, 'BD000003', 'F02'),
	(19, 'BD000003', 'F04'),
	(20, 'BD000003', 'F01'),
	(21, 'JK000001', 'F03'),
	(22, 'JK000001', 'F05'),
	(23, 'JK000001', 'F04'),
	(24, 'JK000001', 'F01'),
	(25, 'JK000002', 'F06'),
	(26, 'JK000002', 'F02'),
	(27, 'JK000002', 'F03'),
	(28, 'JK000002', 'F04'),
	(29, 'SB000001', 'F05'),
	(30, 'SB000001', 'F04'),
	(31, 'SB000001', 'F01'),
	(32, 'SB000002', 'F02'),
	(33, 'SB000002', 'F01'),
	(34, 'SB000002', 'F04'),
	(35, 'SB000003', 'F01'),
	(36, 'SB000003', 'F05'),
	(37, 'SB000003', 'F10'),
	(38, 'SM000001', 'F01'),
	(39, 'SM000001', 'F04'),
	(40, 'SM000001', 'F02'),
	(41, 'SM000001', 'F06'),
	(42, 'SM000002', 'F02'),
	(43, 'SM000002', 'F04'),
	(44, 'SM000002', 'F01');
/*!40000 ALTER TABLE `ft_facilities` ENABLE KEYS */;

-- Dumping structure for table webdev.gallery
CREATE TABLE IF NOT EXISTS `gallery` (
  `kdFoto` int(11) NOT NULL AUTO_INCREMENT,
  `direktori` varchar(50) DEFAULT NULL,
  `kdHotel` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`kdFoto`),
  KEY `FK_gallery_hotel` (`kdHotel`),
  CONSTRAINT `FK_gallery_hotel` FOREIGN KEY (`kdHotel`) REFERENCES `hotel` (`kdHotel`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;

-- Dumping data for table webdev.gallery: ~37 rows (approximately)
/*!40000 ALTER TABLE `gallery` DISABLE KEYS */;
INSERT INTO `gallery` (`kdFoto`, `direktori`, `kdHotel`) VALUES
	(1, 'ib (1)', 'BD000001'),
	(2, 'ib (2)', 'BD000001'),
	(3, 'ib (3)', 'BD000001'),
	(4, 'ib (4)', 'BD000001'),
	(5, 'kr (1)', 'JK000003'),
	(6, 'kr (2)', 'JK000003'),
	(7, 'kr (3)', 'JK000003'),
	(8, 'clv (1)', 'BD000002'),
	(9, 'clv (2)', 'BD000002'),
	(10, 'clv (3)', 'BD000002'),
	(11, 'clv (4)', 'BD000002'),
	(12, 'ar (1)', 'BD000003'),
	(13, 'ar (2)', 'BD000003'),
	(14, 'ar (3)', 'BD000003'),
	(15, 'ar (4)', 'BD000003'),
	(16, 'mel (1)', 'JK000001'),
	(17, 'mel (2)', 'JK000001'),
	(18, 'mel (3)', 'JK000001'),
	(19, 'mel (4)', 'JK000001'),
	(20, 'arj (1)', 'JK000002'),
	(21, 'arj (2)', 'JK000002'),
	(22, 'arj (3)', 'JK000002'),
	(23, 'arj (4)', 'JK000002'),
	(24, 'fv (1)', 'SB000001'),
	(25, 'fv (2)', 'SB000001'),
	(26, 'fv (3)', 'SB000001'),
	(27, 'mj (1)', 'SB000002'),
	(28, 'mj (2)', 'SB000002'),
	(29, 'mj (3)', 'SB000002'),
	(30, 'mj (4)', 'SB000002'),
	(31, 'ric (1)', 'SB000003'),
	(32, 'ric (2)', 'SB000003'),
	(33, 'mg (1)', 'SM000001'),
	(34, 'mg (2)', 'SM000001'),
	(35, 'mg (3)', 'SM000001'),
	(36, 'mg (4)', 'SM000001'),
	(37, 'lo (1)', 'SM000002'),
	(38, 'lo (2)', 'SM000002'),
	(39, 'lo (3)', 'SM000002'),
	(40, 'lo (4)', 'SM000002');
/*!40000 ALTER TABLE `gallery` ENABLE KEYS */;

-- Dumping structure for table webdev.gallery_room
CREATE TABLE IF NOT EXISTS `gallery_room` (
  `kdFotoRoom` int(11) NOT NULL AUTO_INCREMENT,
  `directory` varchar(255) NOT NULL DEFAULT '0',
  `kdHotel` varchar(8) NOT NULL DEFAULT '0',
  `kd_kamar` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`kdFotoRoom`),
  KEY `FK_ft_gallery_hotel` (`kdHotel`),
  KEY `FK_ft_gallery_gallery` (`kd_kamar`),
  CONSTRAINT `FK_ft_gallery_gallery` FOREIGN KEY (`kd_kamar`) REFERENCES `room` (`kd_kamar`),
  CONSTRAINT `FK_ft_gallery_hotel` FOREIGN KEY (`kdHotel`) REFERENCES `hotel` (`kdHotel`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;

-- Dumping data for table webdev.gallery_room: ~26 rows (approximately)
/*!40000 ALTER TABLE `gallery_room` DISABLE KEYS */;
INSERT INTO `gallery_room` (`kdFotoRoom`, `directory`, `kdHotel`, `kd_kamar`) VALUES
	(1, 'twinroom', 'BD000001', 1),
	(3, 'queenroom', 'BD000001', 2),
	(5, 'family', 'BD000001', 3),
	(6, 'suite', 'JK000003', 4),
	(7, 'suite2', 'JK000003', 5),
	(8, 'deluxe', 'JK000003', 6),
	(9, 'family', 'BD000002', 9),
	(12, 'deluxetwin', 'BD000002', 7),
	(14, 'king', 'BD000002', 8),
	(16, 'deluxe', 'BD000003', 10),
	(17, 'suite1', 'BD000003', 11),
	(18, 'suite2', 'BD000003', 12),
	(19, 'deluxe', 'JK000001', 13),
	(20, 'deluxe2', 'JK000001', 14),
	(21, 'exe', 'JK000001', 15),
	(22, 'junior', 'JK000002', 18),
	(23, 'sup1', 'JK000002', 16),
	(24, 'sup2', 'JK000002', 17),
	(25, 'std', 'SB000001', 19),
	(26, 'deluxe', 'SB000001', 20),
	(27, 'klasik', 'SB000002', 21),
	(28, 'heri', 'SB000002', 22),
	(29, 'legend', 'SB000002', 23),
	(30, 'suites1', 'SM000001', 24),
	(31, 'suites1', 'SM000001', 25),
	(32, 'suites1', 'SM000001', 26),
	(33, 'king', 'SM000002', 27),
	(34, 'twin', 'SM000002', 28);
/*!40000 ALTER TABLE `gallery_room` ENABLE KEYS */;

-- Dumping structure for table webdev.hotel
CREATE TABLE IF NOT EXISTS `hotel` (
  `kdHotel` varchar(8) NOT NULL,
  `nama_hotel` varchar(255) DEFAULT NULL,
  `deskripsi` longtext,
  `kdRegion` char(5) DEFAULT NULL,
  `alamat_hotel` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`kdHotel`),
  KEY `kdRegion` (`kdRegion`),
  CONSTRAINT `hotel_ibfk_1` FOREIGN KEY (`kdRegion`) REFERENCES `region` (`kdRegion`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table webdev.hotel: ~10 rows (approximately)
/*!40000 ALTER TABLE `hotel` DISABLE KEYS */;
INSERT INTO `hotel` (`kdHotel`, `nama_hotel`, `deskripsi`, `kdRegion`, `alamat_hotel`) VALUES
	('BD000001', 'Ibis Bandung Trans Studio', 'Ibis Bandung Trans Studio, strategically located in Integrated Trans Studio Bandung Complex, shopping mall and indoor theme park, is the ideal hotel for leisure or business. Enjoy generous meals in a cozy ambiance at Oopen Restaurant. Experience outdoor gathering in our Oopen Terrace. Don\'t feel cut off thanks to our free high-speed Wi-Fi. Have a happy sleep and sweet dreams in our comfy beds. We guarantee you a smooth stay with our "15-minute Satisfaction Guarantee" contract.', 'R0002', 'Jalan Gatot Subroto No. 289, Cibangkong , Buahbatu, Bandung, Jawa Barat, Indonesia, 40273'),
	('BD000002', 'Clove Garden Hotel & Residence', 'Ideal for you to grow up healthy and well as your family. Clove Garden Hotel & Residence also has easy access to universities and leading educational institutions, places of culinary,hospitals, malls and interesting urban spots in Dago and surrounding areas in North Bandung. The best place for you & your family. ', 'R0002', 'Jl. Awiligar Raya Dago Pakar II Bandung Jawa Barat 40191, Dago, Bandung, Jawa Barat, Indonesia, 40191'),
	('BD000003', 'Aryaduta Bandung', 'At Aryaduta, we embody the essence of Indonesian hospitality in every element of our services making it our absolute passion to ensure our guests feel at home. All while celebrating Indonesia’s cultural heritage in our exceptional hotels and resorts.', 'R0002', 'Jl. Sumatera No. 51 Bandung, Merdeka, Bandung, Jawa Barat, Indonesia, 40115'),
	('JK000001', 'Hotel Gran Meliá Jakarta', 'A haven of serenity and luxury in the heart of Indonesia’s capital, Gran Meliá Jakarta is an urban oasis nestled in the prime Golden Triangle central business district of Kuningan,inspired by its Spanish heritage.', 'R0001', 'Jalan H.R. Rasuna Said Kav X-0 - Kuningan, 12950, Jakarta, Indonesia'),
	('JK000002', 'Hotel Aryaduta Jakarta', 'Ideal for work or recreational visits to Jakarta\'s business district, Hotel Aryaduta Jakarta provides an elegant atmosphere in the bustling, downtown cityscape. The luxury hotel is less than ten minutes\' walk from Merdeka Square.', 'R0001', 'Jl. Prajurit KKO Usman & Harun No. 44-48, 10110, Jakarta, Indonesia'),
	('JK000003', 'Hotel Kristal', 'Visit and discover why Kristal Hotel is the favorite place to stay in South Jakarta. Our suites are all designed with your comfort in mind, offering modern kitchen facilities, free Wi-Fi throughout the hotel, relaxing bedrooms and spacious living areas. Everything is in place to make your stay memorable like a home away from home. With the popular Satu Lagi Bar, Life Spa Fitness Centre and large free form swimming pool, there’s nothing left to think about except opening the door to a pleasant stay with us. Let the warmth and friendliness of our staff set the scene for an enjoyable stay with us. We strive and dedicate to please, with our excellent facilities built to deliver the ultimate guest experience and delightful ambience.', 'R0001', 'Jl.Tarogong Raya, Cilandak Barat, 12430, Jakarta, Indonesia'),
	('SB000001', 'Favehotel Graha Agung Surabaya', 'Favehotel Graha Agung is located in a bustling newly developed area in West Surabaya well known as " Singapore of Surabaya" by Citraland in Graha Family Area with close access to the Kota Satelit highway entry gate. favehotel Graha Agung Surabaya is 45 minutes from the airport and one hour moments from the industrial areas of Gresik and Pasuruan. The hotel is surrounded by guest conveniences such as restaurants, business organizations, banks, international schools, shopping malls and nightlife and entertainment venues.', 'R0004', 'Jl. Mayjen Yono Soewoyo, Pakuwon Square AK II No. 10 - 11, 60228, Surabaya, Indonesia'),
	('SB000002', 'Hotel Majapahit', 'Pamper yourself with a visit to the spa, which offers massages, body treatments, and facials. If you\\\'re looking for recreational opportunities, you\\\'ll find a health club, an outdoor pool, and a sauna. This Colonial hotel also features complimentary wireless Internet access, concierge services, and babysitting/childcare (surcharge). Guests can get to nearby shops on the complimentary shuttle.This hotel features 143 spacious and luxurious guestrooms and suites, overlooking magnificent garden courtyards, while 20 Majapahit club rooms featuring exclusive butler service, gold-plated bathroom fixtures and other amenities. Start from 44 sqm, Garden Terrace room features one luxurious bedroom with private terrace overlooks magnificent garden courtyards and spacious bathroom adorned with opulent gold and marble. Guests will be entertained with 45 cable TV channels in all rooms.-Red Bridge / Jembatan Merah -Grahadi -The Surabaya Zoo -Kali MasHotel majapahit is located in the center of Tunjungan-Embong Malang-Basuki Rahmat Shopping and Business district, 35 Minutes from Juanda International Airport.The Nearest airport to hotel is Juanda Surabaya International Airport.For Nearly A Century Now, The Graceful And Elegant Mandarin Oriental Hotel...', 'R0004', '65 Jalan Tunjungan, 60275, Surabaya, Indonesia'),
	('SB000003', 'Rich Palace by SoASIA', 'The Newest 5 Star Hotel in Surabaya is ready to serve you.\r\n\r\nWith a glorious architecture building and magnificant interior design, Rich Palace Hotel Surabaya is located a 5-minute drive from Bukit Darmo Golf Surabaya and a 10-minute drive from Pakuwon Mall as The Bigest Mall in Indonesia, Lenmarc and spazio mall as a hangout places.\r\n\r\nThe spacious modern designed rooms are all fitted with a cable flat-screen TV, wardrobe, and a personal safe. There is also a refrigerator with a minibar and a desk. Suite bathroom comes with free toiletries, bathrobes, and a hairdryer.\r\n\r\nThe concierge service at Rich Palace Hotel Surabaya can assist with free luggage storage. Laundry, dry cleaning, and ironing services are available at additional charges. There is also meeting rooms for guests convenience.\r\n\r\nIts location only 20 minutes away from Juanda Int\'l Airport, Rungkut & Margomulyo industry and the city centre will help you to accommodate your business trip more easily.\r\n\r\nSurrounding with complete public facilities and a wide variety of cuisines.', 'R0004', 'Jl HR Muhammad No. 269 West Surabaya, 60226, Surabaya, Indonesia'),
	('SM000001', 'MG SUITES HOTEL & APARTMENT', 'Located in the exclusive Semarang central business, MG Suites Hotel and Apartment offering the finest accomodation, dining and treatments in the city. The Hotel is ideally placed for business and leisure with easy acces to shoping  destination, airport, and railway station. With the living room and kitchen area in all room types, the guests will feel very comfortable as staying in the apartment. It is suitable for guests who stay for business, families and tourists who come to Semarang.', 'R0003', 'Jalan Petempen No. 294 Gajah Mada, Semarang Tengah, Semarang, Jawa Tengah, Indonesia, 50133'),
	('SM000002', 'Louis Kienne Hotel Simpang Lima', 'Provides you with Luxury At Ease, our signature touch that delivers the perfect balance between luxury living and hospitality. Designed for both short and long stays, LOUIS Kienne is set to offer our signature design and exceptional business, entertainment and lifestyle services at prime locations around the world.', 'R0003', 'Jalan Ahmad Yani No. 137, Semarang Tengah, Semarang, Jawa Tengah, Indonesia, 50241');
/*!40000 ALTER TABLE `hotel` ENABLE KEYS */;

-- Dumping structure for table webdev.msadmin
CREATE TABLE IF NOT EXISTS `msadmin` (
  `kd_admin` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) DEFAULT NULL,
  `passAdmin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`kd_admin`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table webdev.msadmin: ~0 rows (approximately)
/*!40000 ALTER TABLE `msadmin` DISABLE KEYS */;
INSERT INTO `msadmin` (`kd_admin`, `username`, `passAdmin`) VALUES
	(1, 'admin', 'root');
/*!40000 ALTER TABLE `msadmin` ENABLE KEYS */;

-- Dumping structure for table webdev.payment
CREATE TABLE IF NOT EXISTS `payment` (
  `kdPayment` int(11) NOT NULL AUTO_INCREMENT,
  `kdBooking` varchar(30) NOT NULL DEFAULT '0',
  `cardNumber` varchar(100) DEFAULT NULL,
  `kdHotel` varchar(8) DEFAULT NULL,
  `totalPayment` double DEFAULT '0',
  `paid_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`kdPayment`),
  KEY `FK_payment_userscr` (`cardNumber`),
  KEY `FK_payment_hotel` (`kdHotel`),
  KEY `FK_payment_booking` (`kdBooking`),
  CONSTRAINT `FK_payment_booking` FOREIGN KEY (`kdBooking`) REFERENCES `booking` (`kdBooking`),
  CONSTRAINT `FK_payment_hotel` FOREIGN KEY (`kdHotel`) REFERENCES `hotel` (`kdHotel`),
  CONSTRAINT `FK_payment_userscr` FOREIGN KEY (`cardNumber`) REFERENCES `userscr` (`cardNumber`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

-- Dumping data for table webdev.payment: ~1 rows (approximately)
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
INSERT INTO `payment` (`kdPayment`, `kdBooking`, `cardNumber`, `kdHotel`, `totalPayment`, `paid_at`) VALUES
	(20, 'BK5cd91444e37fd', '849357399346464', 'BD000003', 24400000, '2019-05-13 13:53:17'),
	(21, 'BK5cd91db3af180', '937489327583', 'BD000003', 3050000, '2019-05-13 14:34:06');
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;

-- Dumping structure for table webdev.promosi
CREATE TABLE IF NOT EXISTS `promosi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kdPromosi` varchar(50) DEFAULT NULL,
  `presentase` double DEFAULT '0',
  `deskripsi` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table webdev.promosi: ~3 rows (approximately)
/*!40000 ALTER TABLE `promosi` DISABLE KEYS */;
INSERT INTO `promosi` (`id`, `kdPromosi`, `presentase`, `deskripsi`) VALUES
	(1, 'sdsad', 0.2, 'PROMO 20%'),
	(2, '0', 0, 'default'),
	(3, 'PROMOQ', 0.5, 'PROMO 50%');
/*!40000 ALTER TABLE `promosi` ENABLE KEYS */;

-- Dumping structure for table webdev.rating
CREATE TABLE IF NOT EXISTS `rating` (
  `kdRating` int(11) NOT NULL AUTO_INCREMENT,
  `rating` decimal(1,0) DEFAULT '0',
  `komen` longtext,
  `kdHotel` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`kdRating`),
  KEY `FK_rating_hotel` (`kdHotel`),
  CONSTRAINT `FK_rating_hotel` FOREIGN KEY (`kdHotel`) REFERENCES `hotel` (`kdHotel`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table webdev.rating: ~0 rows (approximately)
/*!40000 ALTER TABLE `rating` DISABLE KEYS */;
INSERT INTO `rating` (`kdRating`, `rating`, `komen`, `kdHotel`) VALUES
	(1, 4, 'Keren', NULL);
/*!40000 ALTER TABLE `rating` ENABLE KEYS */;

-- Dumping structure for table webdev.region
CREATE TABLE IF NOT EXISTS `region` (
  `kdRegion` char(5) NOT NULL,
  `nama_region` varchar(255) DEFAULT NULL,
  `deskripsi_region` varchar(4000) DEFAULT NULL,
  `direktori_foto` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`kdRegion`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table webdev.region: ~4 rows (approximately)
/*!40000 ALTER TABLE `region` DISABLE KEYS */;
INSERT INTO `region` (`kdRegion`, `nama_region`, `deskripsi_region`, `direktori_foto`) VALUES
	('R0001', 'Jakarta', 'Jakarta, officially the Special Capital Region of Jakarta (Indonesian: Daerah Khusus Ibu Kota Jakarta), is the current capital and largest city of Indonesia. Located on the northwest coast of the world\'s most populous island, Java, it is the centre of economics, culture and politics of Indonesia, with a population of 10,075,310 as of 2014.[7][9] Jakarta metropolitan area has an area of 6,392 square kilometers, which is known as Jabodetabek (an acronym of Jakarta, Bogor, Depok, Tangerang and Bekasi). It is the world\'s second largest urban agglomeration (after Tokyo) with a population of 30,214,303 as of 2010.[10] Jakarta is predicted to reach 35.6 million people by 2030 to become the world\'s biggest megacity.[11] Jakarta\'s business opportunities, as well as its potential to offer a higher standard of living, attract migrants from across the Indonesian archipelago, combining many communities and cultures.[12] ', 'jkt'),
	('R0002', 'Bandung', 'Bandung is the capital of West Java province in Indonesia. According to the 2015 census, it is Indonesia\'s fourth most populous city after Jakarta, Surabaya, and Bekasi with over 2.5 million inhabitants. At the meantime, Greater Bandung is the country\'s third biggest metropolitan with over 8 million inhabitants.[2] Located 768 metres (2,520 feet) above sea level, approximately 140 kilometres (87 miles) southeast of Jakarta, Bandung has cooler year-round temperatures than most other Indonesian cities. The city lies on a river basin surrounded by volcanic mountains. This topography provides a natural defense system, which was the primary reason for the Dutch East Indies government\'s plan to move the colony capital from Batavia (modern-day Jakarta) to Bandung.', 'bdg'),
	('R0003', 'Semarang', 'Semarang is the capital and largest city of Central Java province in Indonesia. It has an area of 373.78 square kilometres (144.32 sq mi) and a population of approximately 1.8 million people, making it Indonesia\'s seventh most populous city[2] after Jakarta, Surabaya, Bandung, Bekasi, Medan, and Tangerang. The built-up (metro) area had 3,183,516 inhabitants at the 2010 census spread on 2 cities and 26 districts.[3]', 'smg'),
	('R0004', 'Surabaya', 'Surabaya is the capital of East Java province, and the second-largest city in Indonesia. The city has a population of over 3 million within the city proper and over 10 million in the Greater Surabaya metropolitan area, known as Gerbangkertosusila.[2] Located on northeastern Java on the Madura Strait, it is one of the earliest port cities in Southeast Asia. ', 'sby');
/*!40000 ALTER TABLE `region` ENABLE KEYS */;

-- Dumping structure for table webdev.room
CREATE TABLE IF NOT EXISTS `room` (
  `kd_kamar` int(11) NOT NULL AUTO_INCREMENT,
  `nm_kamar` varchar(250) DEFAULT NULL,
  `smoke` bit(1) DEFAULT NULL,
  `breakfast` bit(1) DEFAULT NULL,
  `hargaPerNight` double DEFAULT NULL,
  `kdHotel` varchar(8) DEFAULT NULL,
  `kd_tipe` char(5) DEFAULT NULL,
  `htl_capacity` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`kd_kamar`),
  KEY `FK__room__kd_tipe__22AA2996` (`kd_tipe`),
  KEY `FK_room_hotel` (`kdHotel`),
  CONSTRAINT `FK__room__kd_tipe__22AA2996` FOREIGN KEY (`kd_tipe`) REFERENCES `roomtype` (`kd_tipe`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_room_hotel` FOREIGN KEY (`kdHotel`) REFERENCES `hotel` (`kdHotel`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

-- Dumping data for table webdev.room: ~28 rows (approximately)
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
INSERT INTO `room` (`kd_kamar`, `nm_kamar`, `smoke`, `breakfast`, `hargaPerNight`, `kdHotel`, `kd_tipe`, `htl_capacity`) VALUES
	(1, 'Kamar Standard Twin (Standard Twin Room)', b'0', b'0', 331500, 'BD000001', 'T0007', 30),
	(2, 'Kamar Standard Queen (Standard Queen Room)', b'0', b'0', 390000, 'BD000001', 'T0005', 30),
	(3, 'Family Room (with Breakfast)', b'0', b'1', 663000, 'BD000001', 'F0001', 30),
	(4, 'Suite Studio (Studio Suite with Breakfast)', b'1', b'1', 523138, 'JK000003', 'T0008', 30),
	(5, 'Suite 2 Kamar Tidur (2 Bedroom Suite)', b'0', b'0', 713413, 'JK000003', 'T0008', 30),
	(6, 'Deluxe 2-Kamar Tidur (2 Bedroom Deluxe)', b'0', b'0', 929587, 'JK000003', 'MS001', 30),
	(7, 'Deluxe Twin Bed (with Breakfast)', b'1', b'1', 549999, 'BD000002', 'T0007', 30),
	(8, 'Deluxe King Bed (with Breakfast)', b'1', b'1', 599999, 'BD000002', 'T0006', 30),
	(9, 'Family Suite - Two Bedroom', b'0', b'1', 2249996, 'BD000002', 'F0001', 30),
	(10, 'Deluxe Room Only', b'0', b'0', 1525000, 'BD000003', 'T0002', 30),
	(11, 'Aryaduta Suite', b'1', b'1', 2775000, 'BD000003', 'MS001', 30),
	(12, 'Aryaduta Executive Suite', b'0', b'1', 5275000, 'BD000003', 'MS001', 30),
	(13, 'Deluxe Room Only', b'0', b'0', 1524600, 'JK000001', 'T0002', 30),
	(14, 'Deluxe With Breakfast', b'0', b'1', 1742400, 'JK000001', 'T0002', 30),
	(15, 'Red Level With Executive Lounge Access', b'1', b'1', 2613600, 'JK000001', 'MS001', 30),
	(16, 'Superior Room Only', b'0', b'0', 800000, 'JK000002', 'T0003', 30),
	(17, 'Superior', b'0', b'1', 900000, 'JK000002', 'T0003', 30),
	(18, 'Junior Suite', b'0', b'1', 1700000, 'JK000002', 'MS002', 30),
	(19, 'Standard Room With Breakfast', b'0', b'1', 444312, 'SB000001', 'T0002', 30),
	(20, 'Deluxe', b'0', b'1', 564102, 'SB000001', 'T0002', 30),
	(21, 'Kamar Klasik', b'1', b'1', 1397702, 'SB000002', 'T0006', 30),
	(22, 'Suite (Heritage)', b'0', b'0', 1442000, 'SB000002', 'T0007', 30),
	(23, 'Suite (Majapahit Legendary)', b'0', b'0', 2392001, 'SB000002', 'MS001', 30),
	(24, 'Business Suites Room Only', b'0', b'0', 420000, 'SM000001', 'T0002', 30),
	(25, 'Maven Suites', b'0', b'1', 990000, 'SM000001', 'T0004', 30),
	(26, 'Family Suites', b'0', b'1', 1400000, 'SM000001', 'F0001', 30),
	(27, 'Deluxe Kingbed Room Only', b'0', b'0', 500000, 'SM000002', 'T0006', 30),
	(28, 'Deluxe Twinbed With Breakfast', b'0', b'1', 650000, 'SM000002', 'T0007', 30),
	(29, NULL, NULL, NULL, NULL, NULL, NULL, 30),
	(30, NULL, NULL, NULL, NULL, NULL, NULL, 30);
/*!40000 ALTER TABLE `room` ENABLE KEYS */;

-- Dumping structure for table webdev.roomtype
CREATE TABLE IF NOT EXISTS `roomtype` (
  `kd_tipe` char(5) NOT NULL,
  `nama_tipe` varchar(255) DEFAULT NULL,
  `max_capacity` int(11) DEFAULT NULL,
  `deskripsi_kamar` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`kd_tipe`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table webdev.roomtype: ~11 rows (approximately)
/*!40000 ALTER TABLE `roomtype` DISABLE KEYS */;
INSERT INTO `roomtype` (`kd_tipe`, `nama_tipe`, `max_capacity`, `deskripsi_kamar`) VALUES
	('F0001', 'Family Room', 5, NULL),
	('MS001', 'Master Suite', 3, 'A parlour or living room connected to one or more bedrooms.'),
	('MS002', 'Mini-Suite', 2, 'A single room with a bed and sitting area. Sometimes the sleeping area is in a bedroom separate from the parlour or living room.'),
	('T0001', 'Single Room', 1, 'A room assigned to one person. May have one or more beds.'),
	('T0002', 'Double Room', 2, 'A room assigned to two people. May have one or more beds.'),
	('T0003', 'Triple Room', 3, 'A room assigned to three people. May have two or more beds.'),
	('T0004', 'Quad Room', 4, 'A room assigned to four people. May have two or more beds.'),
	('T0005', 'Queen Room', 2, 'A room with a queen-sized bed. May be occupied by one or more people.'),
	('T0006', 'King Room', 2, 'A room with a king-sized bed. May be occupied by one or more people.'),
	('T0007', 'Twin Room', 2, 'A room with two beds. May be occupied by one or more people.'),
	('T0008', 'Studio Room', 3, 'A room with a studio bed a couch that can be converted into a bed. May also have an additional bed.');
/*!40000 ALTER TABLE `roomtype` ENABLE KEYS */;

-- Dumping structure for table webdev.sysdiagrams
CREATE TABLE IF NOT EXISTS `sysdiagrams` (
  `name` varchar(160) NOT NULL,
  `principal_id` int(11) NOT NULL,
  `diagram_id` int(11) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `definition` longblob,
  PRIMARY KEY (`diagram_id`),
  UNIQUE KEY `UK_principal_name` (`principal_id`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table webdev.sysdiagrams: ~0 rows (approximately)
/*!40000 ALTER TABLE `sysdiagrams` DISABLE KEYS */;
/*!40000 ALTER TABLE `sysdiagrams` ENABLE KEYS */;

-- Dumping structure for table webdev.users
CREATE TABLE IF NOT EXISTS `users` (
  `kode` int(8) NOT NULL AUTO_INCREMENT,
  `email` varchar(200) DEFAULT '0',
  `nama_pertama` varchar(200) DEFAULT '0',
  `nama_belakang` varchar(200) DEFAULT '0',
  `telepon` varchar(200) DEFAULT '0',
  `pass` varchar(200) DEFAULT '0',
  `foto` varchar(200) DEFAULT '0',
  `since` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

-- Dumping data for table webdev.users: ~10 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`kode`, `email`, `nama_pertama`, `nama_belakang`, `telepon`, `pass`, `foto`, `since`) VALUES
	(1, 'john.doe@yahoo.com', 'John', 'Doe', '43645664', '$2y$10$D8.ZWZ4JUEQyZ5SXTC6yX.pUwG4c70rK0ONyDK6OfXzwuqRLThYm6', '0', '2019-04-29 12:02:31'),
	(2, 'mimin@yahya', 'Lisa', 'Siiva', '234234432', '$2y$10$0i.6N0qYBGvLYlGva3O82.P769MxzvxnH8SQwpg.8yKnxtRG76RPC', '0', '2019-04-29 00:00:00'),
	(3, 'woohoo@yahya', 'Ryan', 'Gi', '533453', '$2y$10$s8W5BvXZmWa8XhwbBU6n5eVnGbsIb1XzHteAVzY0IrrhDT38Xsf1W', '0', '2019-04-29 00:00:00'),
	(4, 'tutu@woohoo', 'Lisa', 'Ree', '32554533', '$2y$10$gfN7WfNn/gDn195lcYCZ0OEGFiSEbXEVTrNSn65c7IFfIkS1uZ2Sy', '0', '2019-04-29 00:00:00'),
	(5, 'yahya@yahoo.com', 'Yahya', 'Kumo', '43645664', '$2y$10$r1LnzSsqhtxQWyy6LGb6Xec.JmUmjXu6HEuwKPsOCXy.JvSFjuEAO', '0', '2019-04-29 11:53:34'),
	(6, 'lita@admin.com', 'Nur', 'lita', '087834243324', '$2y$10$dpYvq.yQwUMsKgejf/Zx/.PuwfNMw/Zks9BjMC4ljOkD6VWxI7q.e', '10', '2019-05-08 21:57:40'),
	(7, 'dery@admin.com', 'Dery', 'Afrizal', '08453553366', '$2y$10$HTPGMk3/S3vb1IoYOJfpNuNFIVnfCwA2RC0aro1WKALUL4udFOv.2', '53', '2019-05-13 04:55:54'),
	(8, 'agga@admin.com', 'Agga ', 'Pag', '0854747456467', '$2y$10$CJZ2rZzk.uKnC0rfoV0GKOuAaRwQzthRRPpkvvjWK34pfa1h1W5zK', '0', '2019-04-29 14:57:18'),
	(11, 'aria@admin.com', 'Aria', 'Putra', '08234324234', '$2y$10$eeNruMjECZ.XdUJJ6WR1q.FadqnPJfDT8injvvK/P3uv/r7H4jy8W', '11', '2019-05-13 13:58:47'),
	(12, 'litaa@admin.com', 'Lit', 'Lita', '0823423534545', '$2y$10$XDHufsfcNoLEsLERI7EQWeumza2LSS1RefQ27DmwKt9zV8KCmn602', '0', '2019-04-29 15:30:53'),
	(13, 'michelle@teman.com', 'Michelle', 'P', '08324234254345', '$2y$10$yPqqPHf/vKQvKD3LcrjEi.KPnbiJ/iu3xBUUh6HAHV7g11RL6Du2.', '0', '2019-05-13 13:59:15'),
	(14, 'dera@yahoo.com', 'Dera', 'Afriz', '08345345345', '$2y$10$mM8vbqL9/gcwWrxroBY.G.6cy0lCFgaJM8XGdRh3BfV5zYWRdNNYy', '11', '2019-05-13 14:31:31');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

-- Dumping structure for table webdev.userscr
CREATE TABLE IF NOT EXISTS `userscr` (
  `cardNumber` varchar(100) NOT NULL,
  `valid` varchar(50) DEFAULT NULL,
  `cvc` int(3) DEFAULT NULL,
  `namaCR` varchar(200) NOT NULL,
  `kode` int(8) NOT NULL,
  PRIMARY KEY (`cardNumber`),
  KEY `kode` (`kode`),
  CONSTRAINT `userscr_ibfk_1` FOREIGN KEY (`kode`) REFERENCES `users` (`kode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table webdev.userscr: ~7 rows (approximately)
/*!40000 ALTER TABLE `userscr` DISABLE KEYS */;
INSERT INTO `userscr` (`cardNumber`, `valid`, `cvc`, `namaCR`, `kode`) VALUES
	('2234234343', '12/24', 343, 'Nurlita', 6),
	('345345345533', '06/17', 666, 'John doe', 1),
	('3464565634', '05/19', 323, 'Dery A', 7),
	('353453534', '08/2018', 434, 'Yahya Kumo', 5),
	('849357399346464', '09/19', 954, 'Aria Eka Putra', 11),
	('937489327583', '08/20', 747, 'Dera Afrizal', 14),
	('9384934548783', '08/24', 454, 'Michelle Prizcillya', 13);
/*!40000 ALTER TABLE `userscr` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
