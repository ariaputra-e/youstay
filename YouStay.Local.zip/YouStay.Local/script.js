$(".slideshow > div:gt(0)").hide();
setInterval(function(){
	$('.slideshow > div:first')
		.fadeOut(1000)
		.next()
		.fadeIn(1000)
		.end()
		.appendTo('.slideshow');
	}, 3000);

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    document.getElementById("myBtn").style.display = "block";
  } else {
    document.getElementById("myBtn").style.display = "none";
  }
}

function getDefault() {
	if (document.getElementByClass("promo").value = ""){
		document.getElementByClass("promo").defaultValue = "0";
	}
}

$('input').click(function(e){
    if (e.ctrlKey) {
        $(this).prop('checked', false);
    }
});

$(document).on("click", ".addRoom", function () {
     var roomID = $(this).data('id');
     $(".modal-body #roomID").val(roomID);
});


function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
} 

var modal = document.getElementById('gambarUP');

var img = document.getElementById('galleryModal');
var modalImg = document.getElementById("img01");
img.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
}

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on <span> (x), close the modal
span.onclick = function() { 
  modal.style.display = "none";
}

	/**var foto = document.getElementById("upload");
	var submit = document.createElement("button");
	var divKiri = document.getElementByClass("upload");
	submit.addAttribute("type", "submit");
	submit.innerHTML("Save");

	foto.addEventListener('click', function (submit){
		divKiri.appendChild(submit);
	}); **/