<?php
	include "php/connection.php";
	include "php/session.php";

	$query = "select * from users where kode = ('$sKode')";

	$statement = $connection->prepare($query);
	$statement->execute();

	$data = $statement->fetch();

	if(!isset($_SESSION['kode'])){
		header('Location: profile.php');
	}
?>

<!DOCTYPE html>
<html>
<head>
	<link href='https://fonts.googleapis.com/css?family=Fahkwang' rel='stylesheet'>
	<link href='https://fonts.googleapis.com/css?family=Coda Caption:800' rel='stylesheet'>
	<title>Welcome <?php echo $data['nama_pertama']; ?> !</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="bs/bootstrap.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="bs/bootstrap.js"></script>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<button onclick="topFunction()" id="myBtn" title="Go to top">Top</button> 
<div class ="container">
	<div class="header">
		<div class="logo"> 
			<img src="assets/image/logo.png" width="400em">
		</div>
		<div class="navbar">
			<ul>
			  <li><a class="active" href="index.php">Home</a></li>
			  <li><a href="browse_hotels.php">Hotels</a></li>
			  <li><a href="contact.php">About Us</a></li>
			  <li><a href="profile.php">YOU <img src="assets/image/user.png" width="20px"></a></li>
			  <li><a href="log-out.php">Logout</a></li>
			</ul>
		</div>
	</div>
	<div class="body">
		<div class="container">
			<div class="row">
				<div class="col-md-12" style="margin-top: 5em;">
					<h2>Hello, <?php echo $data['nama_pertama']. " ". $data['nama_belakang'] ?></h2>
				</div>
			</div>
			<div class="row" style="width: 100%; margin-top: 2em; border: 1px solid grey; padding: 40px;">
				<div class="col-md-4 leftProf">
					<div style="width: 200px; background-size: cover; height: 230px; background-image:url('assets/upload/<?php echo $data['foto']; ?>.jpg')" ></div>
					<span><?php echo $data['nama_pertama']. " ". $data['nama_belakang']; ?></span>
				</div>
				<div class="col-md-8 rightProf">
					<div class="table-responsive text-nowrap">
						<table class="table table-striped" border="0">
						<tr>
							<td>Email</td>
							<td><?php echo $data['email']; ?></td>
						</tr>
						<tr>
							<td>Mobile Number</td>
							<td><?php echo $data['telepon']; ?></td>
						</tr>
						<tr>
							<td>Member Since</td>
							<td><?php echo $data['since']; ?></td>
						</tr>
						<tr>
							<td colspan="2" align="center"><a href="edit-profile.php"><button type="button" class="btn btn-info">Edit Profile</button></a>
								<a href="edit-payment.php"><button type="button" class="btn btn-info">Edit Payment Info</button></a></td>
						</tr>
					</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="footer">
		<div class="ft-item">
			<img src="assets/image/logo.png" width="50%">
			<span><p>For more further information <br />please contact us.</p></span>
		</div>
		<div class="ft-item">
			<span class="title"><p>QUICK LINKS</p></span>
			<span class="links">
				<p>About Us</p>
				<p>Our Hotels</p>
				<p>Your Profile</p>
				<p>Admin Page</p>
			</span>
		</div>
		<div class="ft-item" style=" position: relative; top: 4em; left: 6em;">
			<img src="assets/image/fb.png" style="width: 10%;"> 
			<img src="assets/image/ig.png" style="width: 10%;">
		</div>
		<div class="ft-item">
			<div class="title-ig">INSTAGRAM</div>
			<div class="ig">
				<div class="ig-item">
					<img src="assets/image/37.jpg">
				</div>
				<div class="ig-item">
					<img src="assets/image/38.jpg">
				</div>
				<div class="ig-item">
					<img src="assets/image/33.jpg">
				</div>
				<div class="ig-item">
					<img src="assets/image/34.jpg">
				</div>
				<div class="ig-item">
					<img src="assets/image/35.jpg">
				</div>
				<div class="ig-item">
					<img src="assets/image/36.jpg">
				</div>
			</div>
		</div>
		<div class="copyright">
			&copy; Aria Eka Putra. 2019.
		</div>
	</div>
</div>
<script type="text/javascript" src="script.js"></script>
</body>
</html>