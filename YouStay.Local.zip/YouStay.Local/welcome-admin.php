<?php
	include "php/connection.php";
	session_start();

	if(!isset($_SESSION['uname'])){
		header('Location: admin.php');
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Admin Page - YouStay</title>
	<link rel="stylesheet" href="bs/bootstrap.css">
	<script src="bs/bootstrap.js"></script>
	<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container" style="margin: 0 auto; width: 100%;  font-family: Century Gothic, CenturyGothic, AppleGothic, sans-serif;">
	<div class="row" style="width: 100%; background-color: #8f0404; height: 10em; position: fixed; z-index: 5;">
		<img src="assets/image/logo.png" style="width: 15%;">
		<label style="color: white; position: relative; right: 1em; top: .6em;"><b><h1>ADMIN PAGE</h1></b></label>
	</div>
	<div class="row" style="position: relative; top: 3em; left: 8em;">
		<div class="login" style="width: 80%; height: 20em;margin-top: 9em; border: 1px solid grey;">
			<form action="php/login-admin.php" method="post" name="login">
				<table border="0">
					<tr>
						<td style="color: grey; font-family: Century Gothic, CenturyGothic, AppleGothic, sans-serif; font-size: 29pt; font-weight: 800;">Hello Admin!</td>
					</tr>
						<tr>
						<td><a href="booking-records.php"><button type="button" style="width: 100%;
	border-style: none;
	background-color: grey;
	height: 60px;
	color: white;
	font-weight: 750;
	font-family: Century Gothic, CenturyGothic, AppleGothic, sans-serif;">See Booking Records</button></a></td>
					</tr>
					<tr>
						<td><a href="logout-admin.php"><button type="button" style="width: 100%;
	border-style: none;
	background-color: grey;
	height: 60px;
	color: white;
	font-weight: 750;
	font-family: Century Gothic, CenturyGothic, AppleGothic, sans-serif;">Log-Out</button></a></td>
					</tr>
				</table>
			</form>
		</div>
	</div>
</div>
</body>
</html>