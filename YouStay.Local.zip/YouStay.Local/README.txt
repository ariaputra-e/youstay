Cara import db webdev:

Pada aplikasi MySql silakan import file webdev_final.sql yang tersedia di folder db atau dengan run query yang tersedia di dalam file tsb. (Import including schema-table-data).


=============================================================
Untuk membuka index di browser simply type:
http://localhost:[PORT]/YouStay.Local
OR
http://localhost:[PORT]/index.php

!!!!!!!! Please make sure you're connected to the internet for best experience !!!!!!!!!!!! 

ty:)
- Team Roombooking