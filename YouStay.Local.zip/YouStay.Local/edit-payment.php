<?php
	include "php/connection.php";
	include "php/session.php";

	$query = "select * from users where kode = ('$sKode')";

	$statement = $connection->prepare($query);
	$statement->execute();

	$data = $statement->fetch();

	$query_2 = "select * from userscr where kode = ('$sKode') ";

	$statement_2 = $connection->prepare($query_2);
	$statement_2->execute();

	$dataCR = $statement_2->fetch();

	if(!isset($_SESSION['kode'])){
		header('Location: profile.php');
	}
?>

<!DOCTYPE html>
<html>
<head>
	<link href='https://fonts.googleapis.com/css?family=Fahkwang' rel='stylesheet'>
	<link href='https://fonts.googleapis.com/css?family=Coda Caption:800' rel='stylesheet'>
	<title>Edit Payment Info</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="bs/bootstrap.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="bs/bootstrap.js"></script>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<button onclick="topFunction()" id="myBtn" title="Go to top">Top</button> 
<div class ="container">
	<div class="header">
		<div class="logo"> 
			<img src="assets/image/logo.png" width="400em">
		</div>
		<div class="navbar">
			<ul>
			 <li><a class="active" href="index.php">Home</a></li>
			  <li><a href="browse_hotels.php">Hotels</a></li>
			  <li><a href="contact.php">About Us</a></li>
			  <li><a href="
			  	<?php 
			  		if(isset($_SESSION['kode'])){
			  			echo "user_page.php";
			  		} else {
			  			echo "profile.php";
			  		} 
			  	?>">YOU <img src="assets/image/user.png" width="20px"></a></li>
			  <?php
			  if(isset($_SESSION['kode'])){
			  		echo "<li><a href='log-out.php'>Logout</a></li>";
				}
			  ?>
			</ul>
		</div>
	</div>
	<div class="body">
		<div class="container">
			<div class="row">
				<div class="col-md-12" style="margin-top: 5em;">
					<h2>Edit Payment Info</h2>
				</div>
			</div>
			<div class="row" style="width: 100%; margin-top: 2em; border: 1px solid grey; padding: 40px;">
				<div class="col-md-4 leftProf">
					<div style="width: 200px; background-size: cover; height: 230px; background-image:url('assets/upload/<?php echo $data['foto']; ?>.jpg')"></div>
					<span><?php echo $data['nama_pertama']. " ". $data['nama_belakang']; ?></span>
				</div>
				<div class="col-md-8 rightProf">
					<div class="table-responsive text-nowrap">
						<form action="php/paymentUpdate.php" method="post" name="cardInfo">
							<table border="0" class="table table-striped">
								<tr>
									<td colspan="2"><input type="text" name="cardName" placeholder="Name on Card" value="<?php echo $dataCR['namaCR']; ?>"></td>
								</tr>
								<tr>
									<td colspan="2"><input type="text" name="cardNo" placeholder="Card Number" value="<?php echo $dataCR['cardNumber']; ?>"></td>
								</tr>
								<tr>
									<td><input type="text" name="validUntil" placeholder="Valid Until" value="<?php echo $dataCR['valid']; ?>"></td>
									<td><input type="text" name="cvc" placeholder="CVC Code" value="<?php echo $dataCR['cvc']; ?>"></td>
								</tr>
								<tr>
									<td colspan="2"><input type="password" name="userPassConf" placeholder="Confirm Password"></td>
								</tr>
								<tr>
									<td colspan="2" align="right">
										<button type="submit" class="btn btn-info">		Save
										</button>
							</table>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="footer">
		<div class="ft-item">
			<img src="assets/image/logo.png" width="50%">
			<span><p>For more further information <br />please contact us.</p></span>
		</div>
		<div class="ft-item">
			<span class="title"><p>QUICK LINKS</p></span>
			<span class="links">
				<p>About Us</p>
				<p>Our Hotels</p>
				<p>Your Profile</p>
				<p>Admin Page</p>
			</span>
		</div>
		<div class="ft-item" style=" position: relative; top: 4em; left: 6em;">
			<img src="assets/image/fb.png" style="width: 10%;"> 
			<img src="assets/image/ig.png" style="width: 10%;">
		</div>
		<div class="ft-item">
			<div class="title-ig">INSTAGRAM</div>
			<div class="ig">
				<div class="ig-item">
					<img src="assets/image/37.jpg">
				</div>
				<div class="ig-item">
					<img src="assets/image/38.jpg">
				</div>
				<div class="ig-item">
					<img src="assets/image/33.jpg">
				</div>
				<div class="ig-item">
					<img src="assets/image/34.jpg">
				</div>
				<div class="ig-item">
					<img src="assets/image/35.jpg">
				</div>
				<div class="ig-item">
					<img src="assets/image/36.jpg">
				</div>
			</div>
		</div>
		<div class="copyright">
			&copy; Aria Eka Putra. 2019.
		</div>
	</div>
</div>
<script type="text/javascript" src="script.js"></script>
</body>
</html>