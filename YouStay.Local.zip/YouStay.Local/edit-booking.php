<?php
	include "php/connection.php";

	session_start();
	if(!isset($_SESSION['uname'])){
		die ("Silakan Login Terlebih Dahulu!");
		header('Location: admin.php');
	}

	$query = $connection->prepare("select booking.kdBooking, booking.checkin, booking.checkout,
		payment.totalPayment,
		hotel.nama_hotel, users.nama_pertama, users.nama_belakang, users.telepon,
		room.nm_kamar, room.smoke,
		booking.status
		from booking
		inner join payment on booking.kdBooking = payment.kdBooking
		inner join hotel on booking.kdHotel = hotel.kdHotel
		inner join room on booking.kd_kamar = room.kd_kamar
		inner join users on booking.kode = users.kode
		where booking.kdBooking = :kdBooking");
	$query->bindParam(":kdBooking", $_GET['bookNo']);
	$query->execute();
	$row = $query->fetch();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Admin Page - Edit Booking</title>
	<link rel="stylesheet" href="bs/bootstrap.css">
	<script src="bs/bootstrap.js"></script>
	<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container" style="margin: 0 auto; width: 100%;  font-family: Century Gothic, CenturyGothic, AppleGothic, sans-serif;">
	<div class="row" style="width: 100%; background-color: #8f0404; height: 10em; position: fixed; z-index: 5;">
		<img src="assets/image/logo.png" style="width: 15%;">
		<label style="color: white; position: relative; right: 1em; top: .6em;"><b><h1>ADMIN PAGE</h1></b></label>
	</div>
	<div class="row" style="position: relative; top: 3em; left: 8em;">
		<div class="login" style="width: 80%; height: 70%;margin-top: 9em; border: 1px solid grey;padding-bottom: 10em;">
			<form action="php/edit-book.php" method="post" name="login">
				<table border="0">
					<tr>
						<td colspan="2" style="color: grey; font-family: Century Gothic, CenturyGothic, AppleGothic, sans-serif; font-size: 29pt; font-weight: 800;">Booking No. # <?php echo $_GET['bookNo']; ?></td>
					</tr>
					<tr>
						<td class="bold">Guest Name</td>
						<td>
							<input style="border: 1px solid grey; padding: 6px; width: 100%;" type="text" name="nama" value="<?php echo $row['nama_pertama']." ".$row['nama_belakang']; ?>">
						</td>
					</tr>
					<tr>
						<td class="bold">Hotel Name</td>
						<td>
							<input style="background-color: rgba(0,0,0,.2); padding: 6px; width: 100%;" disabled type="text" name="hotelName" value="<?php echo $row['nama_hotel']; ?>">
						</td>
					</tr>
					<tr>
						<td class="bold">Date-in</td>
						<td>
							<input style="background-color: rgba(0,0,0,.2); padding: 6px; width: 100%;" disabled type="text" name="checkin" value="<?php echo $row['checkin']; ?>">
						</td>
					</tr>
					<tr>
						<td class="bold">Date-out</td>
						<td>
							<input style="background-color: rgba(0,0,0,.2); padding: 6px; width: 100%;" disabled type="text" name="checkout" value="<?php echo $row['checkout']; ?>">
						</td>
					</tr>
					<tr>
						<td class="bold">Room Type</td>
						<td>
							<input style="background-color: rgba(0,0,0,.2); padding: 6px; width: 100%;" disabled type="text" name="type" value="<?php echo $row['nm_kamar']; ?>">
						</td>
					</tr>
					<tr>
						<td class="bold">Guest Contact</td>
						<td><input style="border: 1px solid grey; padding: 6px; width: 100%;" type="text" name="telepon" value="<?php echo $row['telepon']; ?>"></td>
					</tr>
					<tr>
						<td class="bold">Total Price</td>
						<td><input style="background-color: rgba(0,0,0,.2); padding: 6px; width: 100%;" disabled type="text" name="type" value="Rp. <?php echo number_format($row['totalPayment']); ?>"></td>
					</tr>
					<tr>
						<td class="bold">Booking Status</td>
						<td>
						<input type="radio" name="status" value="Completed"> Completed &nbsp; 
						<input type="radio" name="status" value="Waiting for Payment"> Waiting for Payment &nbsp;
						<input type="radio" name="status" value="Declined"> Declined/Pending &nbsp;
						<input type="radio" name="status" value="Cancelled"> Cancelled
						</td>
						<tr>
							<td>&nbsp;</td>
						</tr>
						<tr>
							<input type="hidden" name="kdBooking" value="<?php echo $_GET['bookNo']; ?> ">
							<?php $delete = "php/delete-booking.php?bookNo=".$_GET['bookNo']; ?>
							<td><a href="<?php echo $delete; ?>"><button type="button" style="margin-right: 1em;" class="btn btn-default">Delete</button></a>
							<button type="submit" class="btn btn-default">Save</button></td>
						</tr>
					</tr>
				</table>
			</form>
		</div>
	</div>
</div>
</body>
</html>