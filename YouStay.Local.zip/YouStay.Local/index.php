<?php
	include "php/connection.php";

	session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<link href='https://fonts.googleapis.com/css?family=Fahkwang' rel='stylesheet'>
	<link href='https://fonts.googleapis.com/css?family=Coda Caption:800' rel='stylesheet'>
	<title>YouStay - Home</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="bs/bootstrap.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="bs/bootstrap.js"></script>
	<link rel="stylesheet" href="style.css">
</head>
<body>
<button onclick="topFunction()" id="myBtn" title="Go to top">Top</button> 
<div class ="container">
	<div class="header">
		<div class="logo"> 
			<img src="assets/image/logo.png" width="400em">
		</div>
		<div class="navbar">
			<ul>
			  <li><a class="active" href="index.php">Home</a></li>
			  <li><a href="browse_hotels.php">Hotels</a></li>
			  <li><a href="contact.php">About Us</a></li>
			  <li><a href="profile.php">YOU <img src="assets/image/user.png" width="20px"></a></li>
			  <?php
			  if(isset($_SESSION['kode'])){
			  		echo "<li><a href='log-out.php'>Logout</a></li>";
				}
			  ?>
			</ul>
		</div>
	</div>
	<div class="body" style="margin-top: 6em;">
		<div class="slideshow">
			<div>
				<img src="assets/image/52.jpg">
			</div>
			<div>
				<img src="assets/image/48.jpg">
			</div>
		</div>
		<span class="quickBook">
				<table class="formSearch">
					<tr>
						<td>Check In</td>
						<td>Check Out</td>
						<td>Room</td>
						<td>Adult</td>
						<td>Children</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td><input type="date" name="checkIn" placeholder="dd/mm/yyyy"></td>
						<td><input type="date" name="checkOut" placeholder="dd/mm/yyyy"></td>
						<td><select class="small">
							<option>0</option>
							<option>1</option>
							<option>2</option>
							<option>3</option>
							<option>4</option>
							<option>5</option>
							<option>6</option>
							<option>7</option>
							<option>8</option>
							<option>9</option>
						</select></td>
						<td><select class="small">
							<option>0</option>
							<option>1</option>
							<option>2</option>
							<option>3</option>
							<option>4</option>
							<option>5</option>
							<option>6</option>
							<option>7</option>
							<option>8</option>
							<option>9</option>
						</select></td>
						<td><select class="small">
							<option>0</option>
							<option>1</option>
							<option>2</option>
							<option>3</option>
							<option>4</option>
							<option>5</option>
							<option>6</option>
							<option>7</option>
							<option>8</option>
							<option>9</option>
						</select></td>
						<td><a href="browse_hotels.php"><input class = "btn btn-default" type="submit" name="findRoom" value="Find"></a></td>
					</tr>
				</table>
			</span>
		<div class="content">
			<div class="row">
				<div class="pop-title">
					POPULAR HOTELS
				</div>
			</div>
		<?php 
			$query = $connection->prepare("select hotel.kdHotel, hotel.nama_hotel, room.hargaPerNight, gallery.direktori
				from hotel
				inner join room on hotel.kdHotel = room.kdHotel
				inner join gallery on hotel.kdHotel = gallery.kdHotel
				where right(direktori, 3) = '(1)' order by room.hargaPerNight desc limit 1;");

			$query->execute();
			$mostPopular = $query->fetch();
			$link = "hotels.php?id=".$mostPopular['kdHotel'];
		?>
		<div class="row cont" style="border-bottom: 1px solid grey; padding-bottom: 20px"><a href = "<?php echo $link; ?>">
			<div class="col-md-6 image" style="background-size: cover; background-image: url('assets/image/hotels/<?php echo $mostPopular['kdHotel']."/".$mostPopular['direktori']; ?>.jpg');  margin-right: 1em; height: 350px;">
				<span class="box-caption">
					<h2><?php echo $mostPopular['nama_hotel']; ?></h2>
					<p>Rp. <?php echo number_format($mostPopular['hargaPerNight']); ?> ,-</p>
				</span>
			</div></a>
			<?php 
			$query = $connection->prepare("select hotel.kdHotel, hotel.nama_hotel, room.hargaPerNight, gallery.direktori
				from hotel
				inner join room on hotel.kdHotel = room.kdHotel
				inner join gallery on hotel.kdHotel = gallery.kdHotel
				where right(direktori, 3) = '(1)' and hotel.kdHotel != :kdHotel order by room.hargaPerNight desc limit 3;");
			$query->bindParam(":kdHotel", $mostPopular['kdHotel']);
			$query->execute();
			?>
			<div class="col-md-6" style="width: 40%; position: relative; bottom: 1em;">
				<?php while ($mostPopular2 = $query->fetch()){ ?>
				<span class="row">
					<?php $link2 = "hotels.php?id=".$mostPopular2['kdHotel']; ?>
					<a href="<?php echo $link2; ?>"><span class="col-md-3 image" style="background-size: cover; background-image: url('assets/image/hotels/<?php echo $mostPopular2['kdHotel']."/".$mostPopular2['direktori']; ?>.jpg'); height: 100px; width: 150px;"></span></a>
					<span class="col-md-6" style="margin-top: .5em;"><?php echo $mostPopular2['nama_hotel']; ?> <br />
						Rp. <?php echo number_format($mostPopular2['hargaPerNight']); ?> ,- <br />
						<a href="<?php echo $link2; ?>"><button type="button" class="btn btn-primary btn-lg" style="margin-top: .5em; border:none; width: 70%; padding: 1px;">Book</button></a>
					</span>
				</span>
				<?php } ?>
			</div>
		</div>
		<div class="row" style="margin-top: 1em; margin-bottom: 0;">
			<h1 style="font-weight: 800;">Region</h1>
		</div>
			</div>
			<div class="region">
				<a href="browse-region.php?reg=R0001"><div class="reg-item reg1 image"><
					<span><h2>Jakarta</h2></span>
				</div></a>
				<div class="reg-item reg2 image">
					<span><h2>Bandung</h2></span>
				</div>
				<div class="reg-item reg3 image">
					<span><h2>Surabaya</h2></span>
				</div>
				<div class="reg-item reg4 image">
					<span><h2>Semarang</h2></span>
				</div>
				<div class="reg-item reg5 image">
					<span><h2>See More Region..</h2></span>
				</div>
			</div>
		</div>
	</div>
	<div class="subscribe">
		<span>Subscribe for a monthly roundup of best bits. <br />
		Don't worry, we hate spam too - that's why we only send out monthly email!</span>
		<span><input type="text" name="sbscr"> <input type="submit" name="sub" value="Subscribe"></span>
	</div>
	<div class="footer">
		<div class="ft-item">
			<img src="assets/image/logo.png" width="50%">
			<span><p>For more further information <br />please contact us.</p></span>
		</div>
		<div class="ft-item">
			<span class="title"><p>QUICK LINKS</p></span>
			<span class="links">
				<a href="about-us.php" style="color: white;"><p>About Us</p></a>
				<a href="browse_hotels.php" style="color: white;"><p>Our Hotels</p></a>
				<a href="profile.php" style="color: white;"><p>Your Profile</p></a>
				<a href="admin.php" style="color: white;"><p>Admin Page</p></a>
			</span>
		</div>
		<div class="ft-item" style=" position: relative; top: 4em; left: 6em;">
			<img src="assets/image/fb.png" style="width: 10%;"> 
			<img src="assets/image/ig.png" style="width: 10%;">
		</div>
		<div class="ft-item">
			<div class="title-ig">INSTAGRAM</div>
			<div class="ig">
				<div class="ig-item">
					<img src="assets/image/37.jpg">
				</div>
				<div class="ig-item">
					<img src="assets/image/38.jpg">
				</div>
				<div class="ig-item">
					<img src="assets/image/33.jpg">
				</div>
				<div class="ig-item">
					<img src="assets/image/34.jpg">
				</div>
				<div class="ig-item">
					<img src="assets/image/35.jpg">
				</div>
				<div class="ig-item">
					<img src="assets/image/36.jpg">
				</div>
			</div>
		</div>
		<div class="copyright">
			&copy; Aria Eka Putra. 2019.
		</div>
	</div>
</div>
<script type="text/javascript" src="script.js"></script>
</body>
</html>