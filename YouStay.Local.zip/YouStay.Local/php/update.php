<?php
	include "connection.php";
	include "session.php";

	$email = $_POST['userEmail'];
	$fName = $_POST['userFName'];
	$lName = $_POST['userLName'];
	$phone = $_POST['userPhone'];
	//$kode = $_SESSION['kode'];

	$query = "update users set email = ('$email'), nama_pertama = ('$fName'), nama_belakang = ('$lName'), telepon = ('$phone') where kode = ('$sKode')";
	$statement = $connection->prepare($query);
	$statement->execute();

	header('Location: ../user_page.php');
?>