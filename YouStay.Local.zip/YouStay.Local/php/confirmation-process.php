<?php
	include "connection.php";
	session_start();

	$kdBooking = $_POST['kdBooking'];
	$kdhotel = $_POST['hotel'];
	$kdroom = $_POST['room'];
	$checkin = $_POST['inputDateIn'];
	$checkout = $_POST['inputDateOut'];
	$checkout = $_POST['inputDateOut'];
	$qty = $_POST['qty'];
	$child = $_POST['qtyChild'];
	$adult = $_POST['qtyAdult'];
	if ($_POST['promo'] == null){
		$promo = "0";	
	}else{
		$promo = $_POST['promo'];
	}
	$user = $_SESSION['kode'];
	$_SESSION['kdBooking'] =  $_POST['kdBooking'];

	$checkin = date('Y-m-d', strtotime(str_replace("/","-",$_POST['inputDateIn'])));
	$checkout = date('Y-m-d', strtotime(str_replace("/","-",$_POST['inputDateOut'])));

	if(!isset($_POST['smoke'])){
		$smoke = "No";
	}else{
		$smoke = $_POST['smoke'];
	}

	$query = $connection->prepare("insert into booking (
		kdBooking, checkin, checkout, qtyRoom, qtyChild, qtyAdult, kdPromosi, smoke, kode, kdHotel, kd_kamar) 
		values('$kdBooking', '$checkin', '$checkout', '$qty', '$child', '$adult', '$promo', '$smoke', '$user', '$kdhotel', '$kdroom')");

	if(!isset($_SESSION['kode'])){
		die ("<script type='text/javascript'> alert('You need to log-in before proceed!'); window.location.href = '../profile.php';</script>");
	}else{ 
		if($statement = $query->execute()){
			header('Location: ../book-confirm.php');
		}
	}
?>