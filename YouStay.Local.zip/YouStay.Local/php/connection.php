<?php
	$string = "mysql:host=localhost;dbname=webdev";

	$username = "root";
	$password = "root";

	$connection = new PDO($string, $username, $password);
?>