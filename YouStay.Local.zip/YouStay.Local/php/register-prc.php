<?php
	include "connection.php";

	$email = $_POST['userEmail'];
	$fName = $_POST['userFName'];
	$lName = $_POST['userLName'];
	$phone = $_POST['userPhone'];
	$password = password_hash($_POST['userPass'], PASSWORD_BCRYPT);

	$query = "insert into users (email, nama_pertama, nama_belakang, telepon, pass) values (?, ?, ?, ?, ?)";
	$statement = $connection->prepare($query);
	$statement->execute([$email, $fName, $lName, $phone, $password]);

	echo "<script type='text/javascript'>alert ('Register Berhasil, Silahkan Log-in!'); window.location.href = '../profile.php'; </script>";
?>