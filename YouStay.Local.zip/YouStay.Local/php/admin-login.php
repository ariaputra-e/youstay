<?php
	include "connection.php";

	session_start();
	$uname = $_POST['username'];
	$pass = $_POST['pass'];

	$query = "select * from msadmin where username = ?";
	$statement = $connection->prepare($query);
	$statement->execute([$uname]);

	if($row = $statement->fetch()){
		if($pass == $row['passAdmin']){
			$_SESSION['uname'] = $row['username'];
			$_SESSION['pass'] = $row['passAdmin'];
			echo "<script type='text/javascript'>alert ('Log-in Berhasil'); window.location.href = '../welcome-admin.php'; </script>";
		}
		else{
			echo "<script type='text/javascript'>alert ('Log-in Gagal'); window.location.href = '../admin.php'; </script>";
			//header('Location: page_internal.php');
		}
	}else{
		echo "<script type='text/javascript'>alert ('Log-in Gagal');
		 window.location.href = '../admin.php';</script>";
		//header('Location: page_internal.php');
	}
?>
