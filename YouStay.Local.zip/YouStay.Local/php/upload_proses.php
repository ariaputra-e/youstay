<?php
	include "connection.php";
	session_start();

	$foto = $_FILES['uploadFoto'];
	$sKode = $_SESSION['kode'];
	$ext = explode(".", $foto['name']);
	$ext = end($ext);
	$ext = strtolower($ext);
	$title = explode(".", $foto['name']);
	$title = $title[0];
	$title = strtolower($title);

	$query = "update users set foto = '$title' where kode ='$sKode'";

	$extAllowed = ['jpg'];

	if (in_array($ext, $extAllowed)){
		$source = $foto['tmp_name'];
		$dest = '../assets/upload/'.$foto['name'];
		move_uploaded_file($source, $dest);
		$statement = $connection->prepare($query);
		$statement->execute();
		echo "<script type='text/javascript'>alert ('File Berhasil di Upload!'); window.location.href = '../user_page.php'; </script>";
	}else{
		echo "Format file tidak valid coba lagi!";
	}
?>