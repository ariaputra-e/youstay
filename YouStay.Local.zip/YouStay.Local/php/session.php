<?php
	include "connection.php";

	session_start();

	$sEmail = $_SESSION['email'];
	$sFName = $_SESSION['nama_pertama'];
	$sLName = $_SESSION['nama_belakang'];
    $sTelepon = $_SESSION['telepon'];
    $sFoto = $_SESSION['foto'];
	$sSince = $_SESSION['since'];
	$sKode = $_SESSION['kode'];
?>