<?php
	include "connection.php";
	session_start();

	$kdBooking = $_POST['kdBooking'];
	$cardNumber = $_POST['cardNumber'];
	$hotel = $_POST['hotel'];
	$totalPrice = $_POST['totalPrice'];
	$date = date('Y-m-d H:i:s');

	$totalPrice_form = str_replace( ',', '', $totalPrice );

	if(is_numeric($totalPrice_form)) {
	    $totalPrice = $totalPrice_form;
	}

	$query = $connection->prepare("insert into payment (kdBooking, cardNumber, kdHotel, totalPayment) values ('$kdBooking', '$cardNumber', '$hotel', '$totalPrice')");

	$updateStatus = $connection->prepare("update booking set status = 'Paid' where kdBooking = :kdBooking");

	$updateStatus->bindParam(":kdBooking", $kdBooking);

	if(isset($cardNumber)){
		$query->execute();
		$updateStatus->execute();
		echo $kdBooking, $cardNumber, $hotel, $totalPrice, $date;
		header('Location: ../confirm.php');
	}else{
		die("<script type='text/javascript'>alert ('Please Enter Your Credit Card Information!');
		 window.location.href = '../profile.php';</script>");
	}
?>