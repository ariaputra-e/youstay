<?php
  include "connection.php";

  if (isset($_GET['bookNo'])){
    $query = $connection->prepare("delete from payment
where payment.kdBooking = :kdBooking;
delete from booking 
where booking.kdBooking = :kdBooking;");
    $query -> bindParam(":kdBooking", $_GET["bookNo"]);

    $query->execute();

    //echo $_GET['bookNo'];
    header("location: ../booking-records.php");
  }

?>
