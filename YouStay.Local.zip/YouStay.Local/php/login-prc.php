<?php
	include "connection.php";

	session_start();
	$email = $_POST['userEmail'];
	$pass = $_POST['userPass'];

	$query = "select * from users where email = ?";
	$statement = $connection->prepare($query);
	$statement->execute([$email]);

	if($row = $statement->fetch()){
		if(password_verify($pass, $row['pass'])){
			$_SESSION['email'] = $row['email'];
			$_SESSION['nama_pertama'] = $row['nama_pertama'];
			$_SESSION['nama_belakang'] = $row['nama_belakang'];
			$_SESSION['telepon'] = $row['telepon'];
			$_SESSION['foto'] = $row['foto'];
			$_SESSION['since'] = $row['since'];
			$_SESSION['kode'] = $row['kode'];

			echo "<script type='text/javascript'>alert ('Log-in Berhasil'); window.location.href = '../user_page.php'; </script>";
		}
		else{
			echo "<script type='text/javascript'>alert ('Log-in Gagal'); window.location.href = '../profile.php'; </script>";
			//header('Location: page_internal.php');
		}
	}else{
		echo "<script type='text/javascript'>alert ('Log-in Gagal');
		 window.location.href = '../profile.php';</script>";
		//header('Location: page_internal.php');
	}
?>
