<?php
	include "connection.php";
	session_start();

	$kdBooking = $_POST['kdBooking'];
	$name = $_POST['nama'];
	$extr = explode(" ", $name);
	$fname = $extr[0];
	$lname = $extr[1];
	$hotel = $_POST['hotelName'];
	$checkin = $_POST['checkin'];
	$checkout = $_POST['checkout'];
	$room = $_POST['type'];
	$telepon = $_POST['telepon'];
	$price = $_POST['totalPayment'];
	$status = $_POST['status'];
	//$kode = $_SESSION['kode'];

	$query = $connection->prepare("update users, booking
			set users.nama_pertama = :fname, users.nama_belakang = :lname,
			booking.status = :status where booking.kode = users.kode
			and booking.kdBooking = :kdBooking");
	$query->bindParam(":fname", $fname);
	$query->bindParam(":lname", $lname);
	$query->bindParam(":status", $status);
	$query->bindParam(":kdBooking", $kdBooking);

	if ($query->execute()){
		//echo $fname,$lname,$status,$kdBooking;
		header('Location: ../booking-records.php');
	}
?>