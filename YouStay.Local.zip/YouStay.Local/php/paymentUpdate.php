<?php
	include "connection.php";
	include "session.php";

	$cardName = $_POST['cardName'];
	$cardNo = $_POST['cardNo'];
	$valid = $_POST['validUntil'];
	$cvc = $_POST['cvc'];

	//$query = "insert into userscr (cardNumber, valid, cvc, namaCR, kode) values ('$cardNo', '$valid', '$cvc', '$cardName', '$sKode')";

	$query = "replace into userscr (cardNumber, valid, cvc, namaCR, kode) values ('$cardNo', '$valid', '$cvc', '$cardName', '$sKode')";

	/** $query = "IF EXISTS
	(UPDATE userscr SET cardNumber = ('$cardNo'), valid = ('$valid'), cvc = ('$cvc'), namaCR = ('$cardName')  WHERE kode = '$sKode';
			ELSE
    			insert into userscr (cardNumber, valid, cvc, namaCR, kode) values ('$cardNo', '$valid', '$cvc', '$cardName', '$sKode');
		END IF;"; **/

	$statement = $connection->prepare($query);
	$statement->execute();

	header('Location: ../user_page.php');
?>