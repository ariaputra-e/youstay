<?php
	include "php/connection.php";
	session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<link href='https://fonts.googleapis.com/css?family=Fahkwang' rel='stylesheet'>
	<link href='https://fonts.googleapis.com/css?family=Coda Caption:800' rel='stylesheet'>
	<title>About US</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="bs/bootstrap.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.js"></script>
  <script src="bs/bootstrap.js"></script>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<button onclick="topFunction()" id="myBtn" title="Go to top">Top</button> 
<div class="header">
		<div class="logo"> 
			<img src="assets/image/logo.png" width="400em">
		</div>
		<div class="navbar">
			<ul>
			  <li><a class="active" href="index.php">Home</a></li>
			  <li><a href="browse_hotels.php">Hotels</a></li>
			  <li><a href="contact.php">About Us</a></li>
			   <li><a href="
			  	<?php 
			  		if(isset($_SESSION['kode'])){
			  			echo "user_page.php";
			  		} else {
			  			echo "profile.php";
			  		} 
			  	?>">YOU <img src="assets/image/user.png" width="20px"></a></li>
			  <?php
			  if(isset($_SESSION['kode'])){
			  		echo "<li><a href='log-out.php'>Logout</a></li>";
				}
			  ?>
			</ul>
		</div>
</div>
<div class="row content" style="height: 110em;width: 100%; margin: 0 auto;">
	<span class="row" style="background-image: url('assets/image/u619.jpg'); background-size: contain; background-repeat: no-repeat; width: 100%; height: 26em; position: relative; bottom: 35em;">
				<label style="position: relative; left: 25em; top: 8em;color: grey; font-family: Century Gothic, CenturyGothic, AppleGothic, sans-serif; font-size: 29pt; font-weight: 800;"> About Us</label>
	</span>
</div>
<div class="row" style="width: 100%; position: relative; bottom: 75em; left: 1em; padding: 10px; border: 1px solid grey; ">
	<table width="50%" style="border-collapse: separate; border-spacing: 20px; padding: 10px;">
		<tr>
			<td style="background-image: ('assets/image/aria.jpg'); height: 200px;"><img src="assets/image/aria.jpg" style="max-width: 100%;"></td>
			<td width="70%"><label>1. Aria Eka Putra - 00000025749</label></td>
		</tr>
		<tr style="background-color: rgba(0,0,0,.1);">
				<td style="background-image: ('assets/image/lita.jpg'); height: 200px;"><img src="assets/image/lita.jpg" style="max-width: 100%;"></td>
			<td><label>2. Nurlita - 00000026143</label></td>
		
		</tr>
		<tr>
						<td style="background-image: ('assets/image/agga.jpg'); height: 200px;"><img src="assets/image/agga.jpg" style="max-width: 100%;"></td>
			<td><label>3. Agga Pagunnata P. - 00000025763</label></td>

		</tr>
		<tr style="background-color: rgba(0,0,0,.1);">
									<td style="background-image: ('assets/image/food.png'); height: 200px;"><img src="assets/image/food.png" style="max-width: 100%;"></td>
			<td><label>4. Dery afrizal Darmawin - 00000023564</label></td>

		</tr>
	</table>
</div>
</div>
<div class="footer">
	<div class="ft-item">
		<img src="assets/image/logo.png" width="50%">
		<span><p>For more further information <br />please contact us.</p></span>
	</div>
	<div class="ft-item">
		<span class="title"><p>QUICK LINKS</p></span>
		<span class="links">
			<p>About Us</p>
			<p>Our Hotels</p>
			<p>Your Profile</p>
			<p>Admin Page</p>
		</span>
	</div>
	<div class="ft-item" style=" position: relative; top: 4em; left: 6em;">
		<img src="assets/image/fb.png" style="width: 10%;"> 
		<img src="assets/image/ig.png" style="width: 10%;">
	</div>
	<div class="ft-item">
		<div class="title-ig">INSTAGRAM</div>
		<div class="ig">
			<div class="ig-item">
				<img src="assets/image/37.jpg">
			</div>
			<div class="ig-item">
				<img src="assets/image/38.jpg">
			</div>
			<div class="ig-item">
				<img src="assets/image/33.jpg">
			</div>
			<div class="ig-item">
				<img src="assets/image/34.jpg">
			</div>
			<div class="ig-item">
				<img src="assets/image/35.jpg">
			</div>
			<div class="ig-item">
				<img src="assets/image/36.jpg">
			</div>
		</div>
	</div>
	<div class="copyright">
		&copy; Aria Eka Putra. 2019.
	</div>
</div>
<script type="text/javascript">
		$(document).on('click', '[data-toggle="lightbox"]', function(event) {
                event.preventDefault();
                $(this).ekkoLightbox();
            });
</script>
<script type="text/javascript" src="script.js"></script>
</body>
</html>