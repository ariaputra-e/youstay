<!DOCTYPE html>
<html>
<head>
	<title>Admin Page - YouStay</title>
	<link rel="stylesheet" href="bs/bootstrap.css">
	<script src="bs/bootstrap.js"></script>
	<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container" style="margin: 0 auto; width: 100%;  font-family: Century Gothic, CenturyGothic, AppleGothic, sans-serif;">
	<div class="row" style="width: 100%; background-color: #8f0404; height: 10em; position: fixed; z-index: 5;">
		<img src="assets/image/logo.png" style="width: 15%;">
		<label style="color: white; position: relative; right: 1em; top: .6em;"><b><h1>ADMIN PAGE</h1></b></label>
	</div>
	<div class="row" style="position: relative; top: 3em; left: 8em;">
		<div class="login" style="width: 80%;margin-top: 9em; border: 1px solid grey;">
			<form action="php/admin-login.php" method="post" name="login">
				<table border="0">
					<tr>
						<td style="color: grey; font-family: Century Gothic, CenturyGothic, AppleGothic, sans-serif; font-size: 29pt; font-weight: 800;">Log-In</td>
					</tr>
					<tr>
						<td style="margin-top: 2em;""><input type="text" name="username" placeholder="Username" style="width: 100%;
	height: 50px;
	background-color: rgba(0, 0, 0, 0.1);
	border-style: none;
	padding: 10px;
	font-weight: 600;
	font-family: Century Gothic, CenturyGothic, AppleGothic, sans-serif;"></td>
					</tr>
					<tr>
						<td><input type="password" name="pass" placeholder="Password"></td>
					</tr>
					<tr>
						<td><button type="submit" style="width: 100%;
	border-style: none;
	background-color: grey;
	height: 60px;
	color: white;
	font-weight: 750;
	font-family: Century Gothic, CenturyGothic, AppleGothic, sans-serif;">Log-In</button></td>
					</tr>
					<tr>
						<td><a href="index.php"><button type="button" style="width: 100%;
	border-style: none;
	background-color: grey;
	height: 60px;
	color: white;
	font-weight: 750;
	font-family: Century Gothic, CenturyGothic, AppleGothic, sans-serif;">Back to Main Page</button></a></td>
					</tr>
				</table>
			</form>
		</div>
	</div>
</div>
</body>
</html>