<?php
	include "php/connection.php";

	session_start();
	if(isset($_SESSION['kode'])){
		header('Location: user_page.php');
	}
?>

<!DOCTYPE html>
<html>
<head>
	<link href='https://fonts.googleapis.com/css?family=Fahkwang' rel='stylesheet'>
	<link href='https://fonts.googleapis.com/css?family=Coda Caption:800' rel='stylesheet'>
	<title>YOU Register</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="bs/bootstrap.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="bs/bootstrap.js"></script>
	<link rel="stylesheet" href="style.css">
</head>
<body>
<button onclick="topFunction()" id="myBtn" title="Go to top">Top</button> 
<div class ="container">
	<div class="header">
		<div class="logo"> 
			<img src="assets/image/logo.png" width="400em">
		</div>
		<div class="navbar">
			<ul>
			  <li><a class="active" href="index.php">Home</a></li>
			  <li><a href="browse_hotels.php">Hotels</a></li>
			  <li><a href="contact.php">About Us</a></li>
			  <li><a href="profile.php">YOU <img src="assets/image/user.png" width="20px"></a></li>
			</ul>
		</div>
	</div>
	<div class="body">
		<div class="login">
			<form action="php/login-prc.php" method="post" name="login">
				<table border="0">
					<tr>
						<td style="color: grey; font-family: Century Gothic, CenturyGothic, AppleGothic, sans-serif; font-size: 29pt; font-weight: 800;">Log-In</td>
					</tr>
					<tr>
						<td><input type="text" name="userEmail" placeholder="Email Address"></td>
					</tr>
					<tr>
						<td><input type="password" name="userPass" placeholder="Password"></td>
					</tr>
					<tr>
						<td><button type="submit">Log-In</button></td>
					</tr>
				</table>
			</form>
		</div>
		<div class="signup">
			<form action="php/register-prc.php" method="post">
				<table border="0">
					<tr>
						<td style="color: grey; font-family: Century Gothic, CenturyGothic, AppleGothic, sans-serif; font-size: 29pt; font-weight: 800;" colspan="2">Sign-Up</td>
					</tr>
					<tr>
						<td colspan="2"><input type="text" name="userEmail" placeholder="Email Address"></td>
					</tr>
					<tr>
						<td><input type="text" name="userFName" placeholder="First Name" width="60%">
						<td><input type="text" name="userLName" placeholder="Last Name" width="40%"></td>
					</tr>
					<tr>
						<td colspan="2"><input type="text" name="userPhone" placeholder="Phone"></td>
					</tr>
					<tr>
						<td colspan="2"><input type="password" name="userPass" placeholder="Password"></td>
					</tr>
					<tr>
						<td colspan="2"><input type="password" name="userPassConf" placeholder="Re-Enter Password"></td>
					</tr>
					<tr>
						<td colspan="2"><button type="submit">Sign-Up</button></td>
					</tr>
				</table>
			</form>
		</div>
	</div>
	<div class="footer">
		<div class="ft-item">
			<img src="assets/image/logo.png" width="50%">
			<span><p>For more further information <br />please contact us.</p></span>
		</div>
		<div class="ft-item">
			<span class="title"><p>QUICK LINKS</p></span>
			<span class="links">
				<p>About Us</p>
				<p>Our Hotels</p>
				<p>Your Profile</p>
				<p>Admin Page</p>
			</span>
		</div>
		<div class="ft-item" style=" position: relative; top: 4em; left: 6em;">
			<img src="assets/image/fb.png" style="width: 10%;"> 
			<img src="assets/image/ig.png" style="width: 10%;">
		</div>
		<div class="ft-item">
			<div class="title-ig">INSTAGRAM</div>
			<div class="ig">
				<div class="ig-item">
					<img src="assets/image/37.jpg">
				</div>
				<div class="ig-item">
					<img src="assets/image/38.jpg">
				</div>
				<div class="ig-item">
					<img src="assets/image/33.jpg">
				</div>
				<div class="ig-item">
					<img src="assets/image/34.jpg">
				</div>
				<div class="ig-item">
					<img src="assets/image/35.jpg">
				</div>
				<div class="ig-item">
					<img src="assets/image/36.jpg">
				</div>
			</div>
		</div>
		<div class="copyright">
			&copy; Aria Eka Putra. 2019.
		</div>
	</div>
</div>
<script type="text/javascript" src="script.js"></script>
</body>
</html>